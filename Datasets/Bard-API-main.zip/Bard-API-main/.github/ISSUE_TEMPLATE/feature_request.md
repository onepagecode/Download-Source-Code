---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

💚💜 Thank you for interest. ❤️💛
Please make sure to check for more efficient package management. *Please prioritize checking existing issues first. I will repay with higher-quality code.*

**To Reproduce**
- [ ] I have read [README.md](https://github.com/dsdanielpark/Bard-API). Please read me.
- [ ] I have searched for existing issues. *(Most of the issues are duplicates.)*

----------Please delete the content above this line, including this line.-------------


**Solution you'd like**
A clear and concise description of what you want to happen.
