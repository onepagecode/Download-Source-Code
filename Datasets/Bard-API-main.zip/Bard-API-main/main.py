from bardapi import ChatBard


if __name__ == "__main__":
    chat = ChatBard()
    chat.start()
