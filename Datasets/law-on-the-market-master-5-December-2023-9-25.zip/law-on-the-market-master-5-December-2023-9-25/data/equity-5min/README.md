Data unavailable due to licensing constraints from TickData.com.

Please contact authors for assistance in replication or purchase of data.