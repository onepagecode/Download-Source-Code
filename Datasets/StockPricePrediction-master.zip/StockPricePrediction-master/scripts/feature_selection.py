'''
Using Recursive Feature Elimination with Cross-Validation (RFECV), this Python script performs feature selection on stock price data. Although there are several parts commented out and the logic is not fully clear, the code appears to be incomplete or in the process of revision. This is how the script works in a nutshell:

The script first reads a directory path from the command line. The files in this directory should contain stock data in CSV format.
A list of X, a list of Y, and a list of ranking are initialized. X and Y lists are typically used for storing input features and target values, respectively, for machine learning models. Ranking lists appear to be used to store feature rankings.
Each CSV file in the directory is then looped over by the script. Each file should contain:
a. Pandas DataFrame is used to read the data.
b. DataFrame columns (adj_close) are used to create X and Y arrays, but it only selects the first two and last two data points, which seems illogical in a machine learning context. Following these lines, there is a large commented-out section that might contain the original code for creating X and Y.
c. Next, it converts X and Y to numpy arrays and fits an RFECV selector with a Linear Regression estimator. In RFECV, the best number of features is selected by recursive feature elimination and cross-validation.
d. The ranking list is updated with the new ranking obtained from the selector after X and Y are reset to empty lists.
After all files have been processed, it prints out the final ranking.
The commented out sections and peculiar way X and Y are created might cause this script to not work as expected.
'''
#! /usr/bin/python
import sys
import os
import csv
import pandas

from sklearn.feature_selection import RFECV
from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
from sklearn.cross_validation import StratifiedKFold
import numpy as np

def conv(s):
	try:
		s=float(s)
	except ValueError:
		pass    
	return s

def main(dir_path):

	files = os.listdir(dir_path)

	X = []
	y = []

	ranking = []

	for file_name in files:
		with open( os.path.join(dir_path, file_name), 'r') as textfile:
			data = pandas.read_csv(os.path.join(dir_path, file_name), header=0)
			#reader = csv.reader(textfile)
			#next(reader, None)

			start_test = datetime.datetime(2005, 1, 1)

			col = list(data.adj_close)

			X = [ col[:2] ]
			y = [ col[-1], col[-2] ]

			print X
			print y	
			
			'''

			for row in reader:

				if any(row[key] in (None, "") for key in range(len(row))):
					continue

				temp = row[2:7] + row[9:]
				
				for i in range(len(temp)):
					try:
						temp[i] = float(temp[i])
					except Exception, e:
						print temp[i]
						print temp
						print file_name
						print row
						raise e
			
				X.append(temp)
				y.append(float(row[8]))
			'''

		X=np.array(X, np.float64)
		y=np.array(y, np.float64)

		estimator = LinearRegression()
		selector = RFECV(estimator, step=1, cv=StratifiedKFold(y, 2))
		
		selector = selector.fit(X, y)
		
		'''
		except Exception, e:
			print X
			print y			
			raise e
		'''

		X = []
		y = []

		if len(ranking)!=0:
			ranking = [sum(x) for x in zip(ranking, selector.ranking_)]
		else:
			ranking = selector.ranking_

		print ranking

	print ranking

if __name__ == '__main__':
	main(sys.argv[1])
