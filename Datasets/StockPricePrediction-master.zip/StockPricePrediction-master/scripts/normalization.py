"""
The L2 norm method is used in this Python script to normalize data for specific columns in a data frame.

In plain English, it does the following:

It takes two inputs: a dataframe (which is essentially a table of data) and a list of columns to normalize.
It applies the preprocessing.normalize function from the sklearn library to each of the columns specified. Using this function, the data in the column is normalized, which means that values measured on different scales are adjusted to the same scale.
L2 normalization (also known as Euclidean norm) adjusts the values in the column so that the sum of the squares of the values in each row equals 1.
In this case, the original data in the dataframe is replaced with the normalized data when copy=False is used.
A dataframe with normalized columns is returned by the function.
The purpose of this script is to normalize specific columns in a dataframe using the L2 normalization method. Dataframes are changed in-place, so the original dataframe will contain the normalized data after running this function.
"""
#! /usr/bin/python
'''
    Data Normalization
'''

from sklearn import preprocessing

def normalize(file_dataframe, cols):
    '''
        Data Normalization.
    '''

    for col in cols:
        preprocessing.normalize(file_dataframe[col], \
            axis=1, norm='l2', copy=False)

    return file_dataframe