'''
By using spline interpolation, the Python script in focus reads CSV files from a specified directory, fills in any gaps in data within certain columns, and then outputs the results. Here is how the script works in plain English:

Scripts require one command-line argument, which is the path to the CSV files to be processed. The following steps are then taken to process each CSV file within the directory:

At first, the script reads the CSV file into an in-memory pandas DataFrame. Using the 'interpolate' function, it then interpolates specified columns within the DataFrame using spline interpolation. For interpolation, the columns 'high', 'open', 'low', 'close', 'volume', and 'adj_close' will be used.

In a dataset, interpolation allows missing values to be estimated. In spline interpolation, the interpolant (the function estimating the missing values) is a particular type of piecewise polynomial that is referred to as a spline.

This spline's order is 2, so it's a quadratic spline (its segments are quadratic functions). As soon as missing values are interpolated in these columns, the script prints the DataFrame to the console.

As soon as the first file is processed, the operation is halted. This is due to the inclusion of the 'break' command, which causes the script to process only one file before terminating.

The script reads a CSV file, uses quadratic spline interpolation to fill in missing data, and prints out the result. When it encounters a file in a specified directory, it only does this for the first one it encounters.
'''
#! /usr/bin/python
'''
    Data Interpolation
'''

import os, sys
import pandas as pd

def interpolate(dataframe, cols_to_interpolate):

    for col in cols_to_interpolate:
        dataframe[col] = dataframe[col].interpolate('spline', order=2)

    return dataframe


def main(dir_path):
    files = os.listdir(dir_path)
    for file_name in files:
        dataframe = pd.read_csv(os.path.join(dir_path, file_name))
        dataframe = interpolate(dataframe, \
            ['high', 'open', 'low', 'close', 'volume', 'adj_close'])
        print dataframe

        break


if __name__=="__main__":
    main(sys.argv[1])
