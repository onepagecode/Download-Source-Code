"""
It performs a sequence of data processing tasks on CSV files located in a specified directory, ultimately storing the transformed files in a new directory.

Two command-line arguments are accepted by the script. The first is the path to the CSV files that will be processed, and the second is the path to the output directory where the processed files will be stored.

Each CSV file in the input directory is then processed individually as follows:

It creates an in-memory table by reading the CSV file into a pandas DataFrame. In addition to this, it defines the following column names: 'high', 'open', 'low', 'close', 'volume', and 'adj_close'. On these columns, subsequent processing operations will be carried out.

After that, the script uses the function 'interpolate' to perform an interpolation operation on the DataFrame. An interpolation module not shown in the script is presumed to be responsible for estimating missing values.

Once the data has been interpolated, the script uses the normalization module's 'normalize' function to normalize the data. To normalize values, you generally adjust them to a common scale after measuring them on different scales.

In the output directory, the script saves the processed DataFrame as a CSV file, preserving the original filename.

As a key component of a data pipeline, this script performs a number of functions. A CSV file is read, missing values are filled in, certain columns are normalized, and then the processed data is saved back to the original file.
"""
#! /usr/bin/python
'''
    Main File.
'''
import os
import sys
import pandas as pd

from interpolation import interpolate
from normalization import normalize


def main(dir_path, output_dir):
    '''
        Run Pipeline of processes on file one by one.
    '''
    files = os.listdir(dir_path)

    for file_name in files:

        file_dataframe = pd.read_csv(os.path.join(dir_path, file_name))

        cols = ['high', 'open', 'low', 'close', 'volume', 'adj_close']

        file_dataframe = interpolate(file_dataframe, cols)

        file_dataframe = normalize(file_dataframe, cols)

        file_dataframe.to_csv(
            os.path.join(output_dir, file_name), encoding='utf-8')

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
