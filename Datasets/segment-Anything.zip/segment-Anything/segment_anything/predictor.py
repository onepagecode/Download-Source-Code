

'''

Numpy and Torch are imported in this code. In addition, it imports a custom module called "Sam" from the local directory. It also imports a function called "ResizeLongestSide" from another custom module in the local directory. This code sets up the necessary dependencies and modules. Using the "Sam" model, it prepares the environment by importing the necessary libraries and modules. The code also includes a function for resizing images to the longest side.

'''
import numpy as np
import torch

from .modeling import Sam

from typing import Optional, Tuple

from .utils.transforms import ResizeLongestSide


class SamPredictor:
    '''

An initialization method for a class is defined in this code. The method takes a parameter called "sam_model," which is an instance of the "Sam" model. It sets up the class instance by assigning "sam_model" to its "model" attribute. Furthermore, it initializes a "transform" attribute, which is set to an instance of the "ResizeLongestSide" class, based on the "sam_model" instance's image size. Furthermore, it calls the "reset_image()" method to initialize or reset the instance's image.
    
    '''
    def __init__(
        self,
        sam_model: Sam,
    ) -> None:
        """
        
        Uses SAM to calculate the image embedding for an image, and then allows repeated, efficient mask prediction given prompts. Arguments: sam_model (SAM): The mask prediction model to be used.
        
        """
        super().__init__()
        self.model = sam_model
        self.transform = ResizeLongestSide(sam_model.image_encoder.img_size)
        self.reset_image()

    '''
    
    In this code, a method called "set_image" is defined. The method takes two parameters: "image," which represents an image in HWC uint8 format with pixel values in the range of [0, 255], and "image_format," which specifies the color format of the image ("RGB" or "BGR"). This method is used to prepare the provided image for further processing. It first checks if the provided image format is valid, either "RGB" or "BGR." If it isn't, an assertion error occurs. When the image_format differs from what is expected by the model, the method converts it accordingly. A transformation is applied to the image using the "transform" object, which resizes the image to the expected size for the model. After that, the image is converted into a Torch tensor, which is then modified to match the expected Dimensions and device type. It is reshaped, permuted, and expanded to include a batch dimension. Finally, "set_torch_image" is called with the processed image tensor and the original image's shape.
    
    '''
    def set_image(
        self,
        image: np.ndarray,
        image_format: str = "RGB",
    ) -> None:
        """
        
        Calculates the image embeddings for the provided image, allowing masks to be predicted with the 'predict' method. Arguments: image (np.ndarray): The mask image. Expects an HWC uint8 image with pixel values between 0 and 255. image_format (str): The color format of the image, in ['RGB', 'BGR'].
        
        """
        assert image_format in [
            "RGB",
            "BGR",
        ], f"image_format must be in ['RGB', 'BGR'], is {image_format}."
        # import pdb;pdb.set_trace()
        if image_format != self.model.image_format:
            image = image[..., ::-1]

        # Transform the image to the form expected by the model
        # import pdb;pdb.set_trace()
        input_image = self.transform.apply_image(image)
        input_image_torch = torch.as_tensor(input_image, device=self.device)
        input_image_torch = input_image_torch.permute(2, 0, 1).contiguous()[None, :, :, :]

        self.set_torch_image(input_image_torch, image.shape[:2])

    @torch.no_grad()
    '''
    
    Within a class, there is a method called "set_torch_image". Two parameters are taken into account by this method: "transformed_image," a Torch tensor representing the transformed image in the format expected by the model, and "original_image_size," a tuple specifying the original image size. To prepare the transformed image tensor for further processing, this method is used. First, it performs assertions to ensure that the transformed image tensor has the expected shape. Checks that the tensor is 1x3xHxW, where H and W are the dimensions expected by the model's image encoder. An exception is raised if the assertions fail. Next, the method resets the class instance's image attributes to their original values. Following that, the instance's "original_image_size" and "input_size" attributes are assigned based on their values. It preprocesses the transformed image tensor with the "preprocess" method of the model, obtaining the input image for further processing.  After that, it feeds the input image to the model's image encoder and stores the It also sets a flag indicating that the image has been set, enabling other mask prediction methods to be used.
    '''
    def set_torch_image(
        self,
        transformed_image: torch.Tensor,
        original_image_size: Tuple[int, ...],
    ) -> None:
        """
        
        Calculates the image embeddings for the provided image, allowing masks to be predicted. Assumes that the input image has already been transformed into a format that the model expects. Arguments: transformed_image (torch.Tensor): An input image that has been resized with ResizeLongestSide. The original_image_size (tuple(int, int)) is the image's size before transformation (H, W).
        
        """
        assert (
            len(transformed_image.shape) == 4
            and transformed_image.shape[1] == 3
            and max(*transformed_image.shape[2:]) == self.model.image_encoder.img_size
        ), f"set_torch_image input must be BCHW with long side {self.model.image_encoder.img_size}."
        self.reset_image()

        self.original_size = original_image_size
        self.input_size = tuple(transformed_image.shape[-2:])
        input_image = self.model.preprocess(transformed_image)
        self.features, self.interm_features = self.model.image_encoder(input_image)
        self.is_image_set = True

    '''
    
    Within a class, this code defines a method called "predict". The method takes several optional parameters such as "point_coords," "point_labels," "box," and "mask_input," along with various other boolean flags. Its purpose is to predict masks based on input prompts. It expects the image to be previously set using the "set_image" method; otherwise, it raises a runtime error. The method first transforms input prompts, such as point coordinates, labels, and boxes, to match the model's format. It performs necessary conversions and assigns them to corresponding Torch tensors. It then calls "predict_torch" to perform the actual mask prediction. The transformed prompts are passed along with other optional parameters to this method, which results in Torch tensors, such as masks, quality predictions, and low-resolution masks. As a final step, the Torch tensors are converted into NumPy arrays, and the predicted masks, quality predictions, and low-resolution masks are returned.
    
    '''
    def predict(
        self,
        point_coords: Optional[np.ndarray] = None,
        point_labels: Optional[np.ndarray] = None,
        box: Optional[np.ndarray] = None,
        mask_input: Optional[np.ndarray] = None,
        multimask_output: bool = True,
        return_logits: bool = False,
        hq_token_only: bool =False,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        
        Predict masks for the given input prompts, using the currently set image. Arguments: point_coords (np.ndarray or None): A Nx2 array of point prompts. Each point is in (X,Y) in pixels. point_labels (np.ndarray or None): A length N array of labels for each point. It is possible to indicate a foreground point by 1 and a background point by 0. Box (np.ndarray or None): XYXY format box prompt given to the model. mask_input (np.ndarray): A low resolution mask input to the model, usually from a previous prediction iteration. For ambiguous input prompts (such as a single click), this will often yield better masks than a single prediction. If only a single mask is required, the model's predicted quality score can be used to select the best mask. For non-ambiguous prompts, such as multiple             input prompts, multimask_output=False can give better results.           return_logits (bool): Returns un-thresholded mask logits rather than binary masks. Returns: (np.ndarray): The output masks in CxHxW format, where C indicates the number of masks, and (H, W) indicates the original image size. (np.ndarray): An array of length C that contains the quality predictions of the model (np.ndarray): An array of CxHxW, where C is the number             of masks and H=W=256. These low resolution logits can be passed to subsequent iterations as masks.
        
        """
        if not self.is_image_set:
            raise RuntimeError("An image must be set with .set_image(...) before mask prediction.")

        # Transform input prompts
        coords_torch, labels_torch, box_torch, mask_input_torch = None, None, None, None
        if point_coords is not None:
            assert (
                point_labels is not None
            ), "point_labels must be supplied if point_coords is supplied."
            point_coords = self.transform.apply_coords(point_coords, self.original_size)
            coords_torch = torch.as_tensor(point_coords, dtype=torch.float, device=self.device)
            labels_torch = torch.as_tensor(point_labels, dtype=torch.int, device=self.device)
            coords_torch, labels_torch = coords_torch[None, :, :], labels_torch[None, :]
        if box is not None:
            box = self.transform.apply_boxes(box, self.original_size)
            box_torch = torch.as_tensor(box, dtype=torch.float, device=self.device)
            box_torch = box_torch[None, :]
        if mask_input is not None:
            mask_input_torch = torch.as_tensor(mask_input, dtype=torch.float, device=self.device)
            mask_input_torch = mask_input_torch[None, :, :, :]

        masks, iou_predictions, low_res_masks = self.predict_torch(
            coords_torch,
            labels_torch,
            box_torch,
            mask_input_torch,
            multimask_output,
            return_logits=return_logits,
            hq_token_only=hq_token_only,
        )

        masks_np = masks[0].detach().cpu().numpy()
        iou_predictions_np = iou_predictions[0].detach().cpu().numpy()
        low_res_masks_np = low_res_masks[0].detach().cpu().numpy()
        return masks_np, iou_predictions_np, low_res_masks_np

    '''
    
    A method called "predict_torch" is defined within a class and decorated with the @torch.no_grad() decorator. The method performs mask prediction using Torch tensors as inputs. It uses the currently set image to predict masks for given input prompts. The input prompts, such as point coordinates, point labels, boxes, and mask inputs, are expected to be Torch tensors that have already been transformed to the input frame using the "ResizeLongestSide" operation.

The method first checks if an image has been set using the "set_image" method; otherwise, a runtime error is raised. The method then checks if the image coordinates are provided. If they are, it combines the point coordinates and labels into a tuple called "points." If point coordinates are not provided, "points" is set to None. The method then embeds prompts by passing them to the model's prompt encoder. This step produces sparse and dense embeddings. Next, it uses the model's mask decoder to predict low-resolution masks and intersection over unions. This method passes image embeddings, prompt embeddings, multimask output flags, and other parameters to the mask decoder, which upscales the low-resolution masks using postprocessing. When the return_logits flag is False, the predicted masks are thresholded to obtain binary masks. Finally, the Torch tensors of the masks, IOU predictions, and low-resolution masks are returned in the specified format as Torch tensors.
    
    '''
    @torch.no_grad()
    def predict_torch(
        self,
        point_coords: Optional[torch.Tensor],
        point_labels: Optional[torch.Tensor],
        boxes: Optional[torch.Tensor] = None,
        mask_input: Optional[torch.Tensor] = None,
        multimask_output: bool = True,
        return_logits: bool = False,
        hq_token_only: bool =False,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        
        Using the currently set image, predict masks for the input prompts. The input prompts are batched torch tensors and should already be resized to the input frame by ResizeLongestSide.

        Arguments:
          point_coords (torch.Tensor or None): A BxNx2 array of point prompts to the
            model. Each point is in (X,Y) in pixels. point_labels (torch.Tensor or None): A BxN array of labels for each point. A foreground point is indicated by 1 and a background point by 0. boxes (np.ndarray or None): A Bx4 array that is a box prompt given to the model in XYXY format. mask_input (np.ndarray): The model is given a low resolution mask input from a previous prediction iteration. Has form Bx1xHxW, where H=W=256 for SAM. It is not necessary to transform masks returned by the predict method in the previous iteration. Generally, this will produce better masks than a single prediction for ambiguous input prompts (such as a single click). multimask_output (bool): If true, the model will return three masks. If only a single mask is required, the model's predicted quality score can be used to select the best mask. Multimask_output=False can yield better results for non-ambiguous prompts like multiple input prompts. Return_logits (bool): Returns un-thresholded mask logits instead of binary masks. (torch.Tensor): The output masks in BxCxHxW format, where (H, W) is the original image size.           (torch.Tensor): An array of shape BxC containing the model's             predictions for the (torch.Tensor): An array of shape BxCxHxW, where C is the number of masks and H is the number of rows. These low res logits can be passed to subsequent iterations as masks.
        
        """
        if not self.is_image_set:
            raise RuntimeError("An image must be set with .set_image(...) before mask prediction.")

        if point_coords is not None:
            points = (point_coords, point_labels)
        else:
            points = None

        # Embed prompts
        sparse_embeddings, dense_embeddings = self.model.prompt_encoder(
            points=points,
            boxes=boxes,
            masks=mask_input,
        )

        # Predict masks
        low_res_masks, iou_predictions = self.model.mask_decoder(
            image_embeddings=self.features,
            image_pe=self.model.prompt_encoder.get_dense_pe(),
            sparse_prompt_embeddings=sparse_embeddings,
            dense_prompt_embeddings=dense_embeddings,
            multimask_output=multimask_output,
            hq_token_only=hq_token_only,
            interm_embeddings=self.interm_features,
        )

        # Upscale the masks to the original image resolution
        masks = self.model.postprocess_masks(low_res_masks, self.input_size, self.original_size)

        if not return_logits:
            masks = masks > self.model.mask_threshold

        return masks, iou_predictions, low_res_masks

    '''

In this code, a method called "get_image_embedding" is defined. The method does not take any parameters. It retrieves the image embeddings for the currently selected image. As a Torch tensor, image embeddings have the shape 1xCxHxW, where C is the embedding dimension and (H, W) is the embedding spatial dimension. In the case of the SAM model, the embedding dimension is typically 256, and the spatial dimensions are 64x64. This method first checks if an image has been set. If an image has not been set, it raises a runtime error. It then asserts that the "features" attribute does not contain None. The assertion ensures that image embeddings exist if an image is set. If the assertion fails, an exception is raised. Finally, a Torch tensor is returned.
    
    '''
    def get_image_embedding(self) -> torch.Tensor:
        """
        
        Returns the image embeddings for the currently set image, with dimensions 1xCxHxW, where C is the embedding dimension and (H,W) is the embedding spatial dimension of SAM (typically C=256, H=W=64).
        
        """
        if not self.is_image_set:
            raise RuntimeError(
                "An image must be set with .set_image(...) to generate an embedding."
            )
        assert self.features is not None, "Features must exist if an image has been set."
        return self.features

    '''
    
    The code defines two methods within a class: a property getter method called "device" and a method called "reset_image." The property getter method retrieves the device on which the model is currently located. It returns the device associated with the model instance. The "reset_image" method resets the image associated with the class instance. "is_image_set" is set to False, indicating that no image is currently set. Also reset is the "features" attribute, which stores the image embeddings, as well as the dimensions of the original and input images (orig_h, orig_w, input_h, input_w). The purpose of this method is to prepare the instance for receiving and processing a new image.
    
    '''
    @property
    def device(self) -> torch.device:
        return self.model.device

    def reset_image(self) -> None:
        """Resets the currently set image."""
        self.is_image_set = False
        self.features = None
        self.orig_h = None
        self.orig_w = None
        self.input_h = None
        self.input_w = None
