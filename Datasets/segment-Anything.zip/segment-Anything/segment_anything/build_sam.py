

'''
This code imports the necessary modules from the PyTorch library and other dependencies. It includes the following modules: torch, partial from functools, ImageEncoderViT, MaskDecoderHQ, PromptEncoder, Sam, and TwoWayTransformer from the local .modeling module.

Without the actual code, it is difficult to determine the exact functionality of the imported modules. However, based on the names, it appears that this code might be related to deep learning models for image encoding, mask decoding, prompt encoding, and transformer-based architectures. These modules could potentially be used for tasks like image recognition, image generation, or natural language processing in the context of computer vision applications.

Overall, this code sets up the necessary imports for working with PyTorch and some custom modeling modules.
'''
import torch

from functools import partial

from .modeling import ImageEncoderViT, MaskDecoderHQ, PromptEncoder, Sam, TwoWayTransformer


'''
This code defines a function called build_sam_vit_h that takes an optional checkpoint parameter. Inside the function, it calls another function _build_sam with specific arguments and returns the result.

The _build_sam function is not shown in the provided code, so we cannot determine its exact implementation. However, based on the provided arguments, it seems to be constructing a specific type of self-attention model (SAM) with a Vision Transformer (ViT) backbone.

The arguments passed to _build_sam specify various parameters for the SAM and ViT, such as the embedding dimension, depth, number of heads, and global attention indexes. These parameters influence the architecture and behavior of the SAM and ViT models.

After defining the build_sam_vit_h function, the code assigns it to another variable called build_sam. This allows the build_sam variable to be used as a reference to the build_sam_vit_h function elsewhere in the code.

In summary, this code defines a function that builds a specific type of self-attention model with a Vision Transformer backbone, and assigns it to the build_sam variable for later use. The exact details of the model construction are determined by the internal _build_sam function, which is not shown in the provided code snippet.
'''
def build_sam_vit_h(checkpoint=None):
    return _build_sam(
        encoder_embed_dim=1280,
        encoder_depth=32,
        encoder_num_heads=16,
        encoder_global_attn_indexes=[7, 15, 23, 31],
        checkpoint=checkpoint,
    )


build_sam = build_sam_vit_h


'''
This code defines a function called build_sam_vit_l that takes an optional checkpoint parameter. Inside the function, it calls another function _build_sam with specific arguments and returns the result.

The _build_sam function is not shown in the provided code, so we cannot determine its exact implementation. However, based on the provided arguments, it seems to be constructing a specific type of self-attention model (SAM) with a Vision Transformer (ViT) backbone.

The arguments passed to _build_sam specify various parameters for the SAM and ViT, such as the embedding dimension, depth, number of heads, and global attention indexes. These parameters influence the architecture and behavior of the SAM and ViT models.

After defining the build_sam_vit_l function, the code assigns it to another variable called build_sam. This allows the build_sam variable to be used as a reference to the build_sam_vit_l function elsewhere in the code.

In summary, this code defines a function that builds a specific type of self-attention model with a Vision Transformer backbone, and assigns it to the build_sam variable for later use. The exact details of the model construction are determined by the internal _build_sam function, which is not shown in the provided code snippet. The specific parameters used in this case result in a smaller variant of the model compared to the previous example.
'''
def build_sam_vit_l(checkpoint=None):
    return _build_sam(
        encoder_embed_dim=1024,
        encoder_depth=24,
        encoder_num_heads=16,
        encoder_global_attn_indexes=[5, 11, 17, 23],
        checkpoint=checkpoint,
    )


'''
This code defines a function called build_sam_vit_b that takes an optional checkpoint parameter. Inside the function, it calls another function _build_sam with specific arguments and returns the result.

The _build_sam function is not shown in the provided code, so we cannot determine its exact implementation. However, based on the provided arguments, it seems to be constructing a specific type of self-attention model (SAM) with a Vision Transformer (ViT) backbone.

The arguments passed to _build_sam specify various parameters for the SAM and ViT, such as the embedding dimension, depth, number of heads, and global attention indexes. These parameters influence the architecture and behavior of the SAM and ViT models.

After defining the build_sam_vit_b function, the code assigns it to another variable called build_sam. This allows the build_sam variable to be used as a reference to the build_sam_vit_b function elsewhere in the code.

In summary, this code defines a function that builds a specific type of self-attention model with a Vision Transformer backbone, and assigns it to the build_sam variable for later use. The exact details of the model construction are determined by the internal _build_sam function, which is not shown in the provided code snippet. The specific parameters used in this case result in a smaller variant of the model compared to the previous examples.
'''
def build_sam_vit_b(checkpoint=None):
    return _build_sam(
        encoder_embed_dim=768,
        encoder_depth=12,
        encoder_num_heads=12,
        encoder_global_attn_indexes=[2, 5, 8, 11],
        checkpoint=checkpoint,
    )


'''
This code creates a dictionary called sam_model_registry that associates specific keys with corresponding values, which are function references.

The keys in the dictionary are strings, including "default", "vit_h", "vit_l", and "vit_b". The values associated with these keys are the functions build_sam_vit_h, build_sam_vit_l, and build_sam_vit_b.

By using this dictionary, different functions can be accessed by referring to the corresponding key. For example, sam_model_registry["default"] will return the function build_sam_vit_h, while sam_model_registry["vit_l"] will return the function build_sam_vit_l.

This dictionary serves as a convenient way to organize and access different SAM (self-attention model) configurations based on their associated keys. It allows for easy selection of the appropriate SAM model based on the desired configuration, making the code more modular and flexible.
'''
sam_model_registry = {
    "default": build_sam_vit_h,
    "vit_h": build_sam_vit_h,
    "vit_l": build_sam_vit_l,
    "vit_b": build_sam_vit_b,
}


'''
The function _build_sam is responsible for building an instance of the SAM (Segment Anything Model), specifically configured for image segmentation.

First, it defines a number of parameters, such as the dimensions of the image and the patches that the Vision Transformer (ViT) will use to break down the image, and the dimensions of the encoder's embeddings.
Then it constructs the SAM model by specifying its three main components: an ImageEncoderViT (which transforms the input image into a form that can be processed by the model), a PromptEncoder (which prepares the prompts for the model), and a MaskDecoderHQ (which generates the output segmentation masks).
The ImageEncoderViT is configured with various parameters such as the depth of the network, the dimensions of the embeddings, and the size of the patches that it will generate from the input image.
The PromptEncoder is configured with the dimensions of the embeddings and the sizes of the input image and the image embeddings.
The MaskDecoderHQ is configured with parameters for the TwoWayTransformer (a component of the decoder) and dimensions for the input/output layers of the decoder.
After constructing the SAM model, it checks if a checkpoint file is provided. If so, it loads the model weights from the checkpoint file. This allows the model to start from a previously saved state, which is useful when you want to continue training from a certain point or use a pre-trained model.
Finally, it iterates through all the parameters of the model and, except for the parameters related to certain components (like the 'hf_token', 'hf_mlp', etc.), it sets them to not require gradients. This essentially freezes those parameters during training, meaning they won't be updated. The function then returns the constructed SAM model.
'''
def _build_sam(
    encoder_embed_dim,
    encoder_depth,
    encoder_num_heads,
    encoder_global_attn_indexes,
    checkpoint=None,
):
    prompt_embed_dim = 256
    image_size = 1024
    vit_patch_size = 16
    image_embedding_size = image_size // vit_patch_size
    sam = Sam(
        image_encoder=ImageEncoderViT(
            depth=encoder_depth,
            embed_dim=encoder_embed_dim,
            img_size=image_size,
            mlp_ratio=4,
            norm_layer=partial(torch.nn.LayerNorm, eps=1e-6),
            num_heads=encoder_num_heads,
            patch_size=vit_patch_size,
            qkv_bias=True,
            use_rel_pos=True,
            global_attn_indexes=encoder_global_attn_indexes,
            window_size=14,
            out_chans=prompt_embed_dim,
        ),
        prompt_encoder=PromptEncoder(
            embed_dim=prompt_embed_dim,
            image_embedding_size=(image_embedding_size, image_embedding_size),
            input_image_size=(image_size, image_size),
            mask_in_chans=16,
        ),
        mask_decoder=MaskDecoderHQ(
            num_multimask_outputs=3,
            transformer=TwoWayTransformer(
                depth=2,
                embedding_dim=prompt_embed_dim,
                mlp_dim=2048,
                num_heads=8,
            ),
            transformer_dim=prompt_embed_dim,
            iou_head_depth=3,
            iou_head_hidden_dim=256,
            vit_dim=encoder_embed_dim,
        ),
        pixel_mean=[123.675, 116.28, 103.53],
        pixel_std=[58.395, 57.12, 57.375],
    )
    # sam.eval()
    if checkpoint is not None:
        with open(checkpoint, "rb") as f:
            state_dict = torch.load(f)
        info = sam.load_state_dict(state_dict, strict=False)
        print(info)
    for n, p in sam.named_parameters():
        if 'hf_token' not in n and 'hf_mlp' not in n and 'compress_vit_feat' not in n and 'embedding_encoder' not in n and 'embedding_maskfeature' not in n:
            p.requires_grad = False

    return sam
