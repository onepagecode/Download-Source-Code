"""
The Keras API is used in this code to implement a neural network. The "pandas" and "numpy" libraries are used for data manipulation, while the "random" and "time" libraries are used to set the random seed and track the execution of the code, respectively. For feature scaling and one-hot encoding of categorical variables, the "OneHotEncoder" and "StandardScaler,RobustScaler" libraries are used. Using the "Statistics" module, you can compute the performance metrics of your trading strategy.

A neural network is created and trained using the "tensorflow" library. A neural network architecture consists of the "CuDNNLSTM", "LSTM", "Dropout", "Dense", and "Input" layers. Early stopping is handled by the "EarlyStopping", "ModelCheckpoint", and "CSVLogger" callbacks. A training algorithm is selected using the "optimizers" module. During the training process, warning messages are filtered out using the "warnings" library.
"""
import pandas as pd
import numpy as np
import random
import time
import pickle
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler,RobustScaler
from Statistics import Statistics

import tensorflow as tf
from tensorflow.keras.layers import CuDNNLSTM,LSTM,Dropout,Dense,Input 
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, CSVLogger 
from tensorflow.keras.models import Model, Sequential 
from tensorflow.keras import optimizers
import warnings
warnings.filterwarnings("ignore")

"""
Numpy and TensorFlow use this code to set the random seed for their random number generators. It ensures that the code produces the same random results every time, which is useful for debugging, testing, and reproducing experiments.

Seed is set to 9 and stored in variable SEED. To ensure that hash values are reproducible in dictionaries and sets, the os.environ command sets the environment variable PYTHONHASHSEED to the same value.

For the Python random and Numpy random number generators, random.seed(SEED) and np.random.seed(SEED) command set the seed. Each time the random number generators are called, the same sequence of numbers is produced.

TensorFlow's random number generator is seeded with a random seed by the tf.set_random_seed(SEED) command.
"""
import os
SEED = 9
os.environ['PYTHONHASHSEED']=str(SEED)
random.seed(SEED)
np.random.seed(SEED)
tf.set_random_seed(SEED)

"""
In this code block, the SPXconst.csv file is read in which contains the constituents of the S&P 500 index over time. Using the read_csv method, the file is read into a pandas dataframe. The dataframe values are flattened, and any null values are removed, to produce the list of all companies. A constituents dictionary is then created using dictionary comprehension. Dataframe columns are joined in reverse order to create the dictionary's keys, which are dates in string format. As of that date, the values correspond to the names of the companies that were constituents.

Each year's constituents_train dictionary is created by iterating over the years 1993 to 2015 and creating a list of months as strings. As with the constituents dictionary keys, these strings follow the same format as the keys. In the constituents_train dictionary, the company names for each month are extracted and concatenated into a set, which is assigned as the value for that year's key. For each training year, this dictionary is used to determine which companies are included in the dataset.
"""
SP500_df = pd.read_csv('data/SPXconst.csv')
all_companies = list(set(SP500_df.values.flatten()))
all_companies.remove(np.nan)

constituents = {'-'.join(col.split('/')[::-1]):set(SP500_df[col].dropna()) 
                for col in SP500_df.columns}

constituents_train = {} 
for test_year in range(1993,2016):
    months = [str(t)+'-0'+str(m) if m<10 else str(t)+'-'+str(m) 
              for t in range(test_year-3,test_year) for m in range(1,13)]
    constituents_train[test_year] = [list(constituents[m]) for m in months]
    constituents_train[test_year] = set([i for sublist in constituents_train[test_year] 
                                         for i in sublist])
    
"""
A simple LSTM model is returned by this function.

First, the input layer of the model is defined with a shape of (sequence_length,1), where sequence_length is the number of time steps in the input sequence.

Then it adds a LSTM layer with the specified number of cells, an activation function 'tanh', and a recurrent activation function 'sigmoid'. To prevent overfitting, this layer has a dropout rate of 0.1 and a recurrent dropout rate of 0.1.

In the next step, we add a dense layer with two output nodes and a softmax activation function. Using this layer, input sequences are classified into long and short classes.

A categorical crossentropy loss function, an RMSprop optimizer, and an accuracy metric are compiled at the end of the function.

A summary of the model architecture is printed and the compiled model is returned.
"""
def makeSimpleLSTM(cells=25):
    inputs = Input(shape=(sequence_length,1))
    x = LSTM(cells,activation='tanh', recurrent_activation='sigmoid',
                   input_shape=(sequence_length,1),
                   dropout=0.1,recurrent_dropout=0.1)(inputs)
    outputs = Dense(2,activation='softmax')(x)
    model = Model(inputs=inputs, outputs=outputs)
    model.compile(loss='categorical_crossentropy',optimizer=optimizers.RMSprop(),
                          metrics=['accuracy'])
    model.summary()
    return model

#-----------
## DOne dnana done 

"""
A CuDNNLSTM model with the specified number of cells is defined and returned by this function. In TensorFlow, the CuDNNLSTM layer is an optimized LSTM (Long Short-Term Memory) layer.

Input to the model is given by shape (sequence_length, 1), where the first dimension corresponds to the length of the input sequence, and the second dimension corresponds to the number of features in each timestep. To prevent overfitting, the output of the LSTM layer is passed through a dropout layer. Lastly, the output is passed through a dense layer with a softmax activation function, which gives the probability of the input belonging to one of two classes.

RMSprop optimizer is used to compile the model, and accuracy metrics are used to evaluate performance. The function prints the model architecture summary to the console, and it returns the compiled model.
"""
def makeCuDNNLSTM(cells=25):
    inputs = Input(shape=(sequence_length,1))
    x = CuDNNLSTM(cells,return_sequences=False)(inputs)
    x = Dropout(0.1)(x)
    outputs = Dense(2,activation='softmax')(x)
    model = Model(inputs=inputs, outputs=outputs)
    model.compile(loss='categorical_crossentropy',optimizer=optimizers.RMSprop(),
                          metrics=['accuracy'])
    model.summary()
    return model  

"""
As part of the training process, this function specifies the callbacks that will be used. LSTMs and CuDNNLSTMs are differentiated by the model_type parameter. An early stopping callback, a CSVlogger, and a ModelCheckpoint are returned by the function.

For further analysis, the training metrics are logged into a CSV file using CSVLogger. A training-log file contains information about loss, accuracy, and other metrics for each epoch.

Based on the validation loss, the ModelCheckpoint saves the best model weights. An epoch number, along with the model type, and the current test year, are included in the file naming convention.

When the validation loss stops improving after a certain number of epochs (patience), the EarlyStopping callback stops the training process. When training is stopped, the best weights are restored by setting restore_best_weights to True.

In general, these callbacks ensure that the best model is saved while preventing overfitting during the training process.
"""
def callbacks_req(model_type='LSTM'):
    csv_logger = CSVLogger(model_folder+'/training-log-'+model_type+'-'+str(test_year)+'.csv')
    filepath = model_folder+"/model-" + model_type + '-' + str(test_year) + "-E{epoch:02d}.h5"
    model_checkpoint = ModelCheckpoint(filepath, monitor='val_loss',save_best_only=True)
    earlyStopping = EarlyStopping(monitor='val_loss',mode='min',patience=10,restore_best_weights=True)
    return [csv_logger,earlyStopping,model_checkpoint]

"""
A model type, LSTM or CuDNNLSTM, is passed to the trainer() function along with training and test data. Train_x and train_y are separated from the training data after it is shuffled. Train_x contains the input features and train_y contains the labels corresponding to those features.

The labels are then converted into one-hot encoded vectors using OneHotEncoder() for softmax activation. By using the appropriate model type and optimizer, the model is then built and compiled.

Using early stopping, the function fits the model to the training data if the validation loss doesn't improve after a certain number of iterations. Callbacks are used to save the model weights and training history to disk.

Lastly, the function generates predictions based on the test data and returns them as a dictionary with the keys being the test dates and the values being the predicted probability of a positive return.
"""
def trainer(train_data,test_data,model_type='CuDNNLSTM'):
    
    np.random.shuffle(train_data)
    train_x,train_y = train_data[:,2:-2],train_data[:,-1]
    train_x = np.reshape(train_x,(len(train_x),sequence_length,1))
    train_y = np.reshape(train_y,(-1, 1))
    
    enc = OneHotEncoder(handle_unknown='ignore')
    enc.fit(train_y)
    enc_y = enc.transform(train_y).toarray()

    if model_type == 'LSTM':
        model = makeSimpleLSTM()
    elif model_type == 'CuDNNLSTM':
        model = makeCuDNNLSTM()
    else:
        return
    callbacks = callbacks_req(model_type)
    
    model.fit(train_x,
              enc_y,
              epochs=1000,
              validation_split=0.2,
              callbacks=callbacks,
              batch_size=512
              )

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = np.reshape(test_d[:,2:-2],(len(test_d),sequence_length,1))
        predictions[day] = model.predict(test_d)[:,1]
    return predictions

"""
It defines a function called trained that takes three arguments: filename, train_data, and test_data. Using the pre-trained model loaded from the specified file, the function makes predictions based on the test data.

To load pre-trained models, the function first calls the load_model function in the Keras API. It reads a model architecture and its trained weights from a file and returns a Keras model instance. Saved models are located at the location specified by the filename argument.

The function then generates predictions for each day based on the loaded model, iterating over the test data. A function selects rows of test_data that correspond to a particular day and reshapes the input data into the format expected by the model (i.e., a 3D tensor with shape (num_samples, sequence_length, num_features). To generate predictions for the reshaped input data, the function uses the predict method of the Keras model instance. In a dictionary called predictions, the predicted values are stored as keys, and the dates as values.

In the end, the function returns a dictionary of predictions.
"""
def trained(filename,train_data,test_data):
    model = load_model(filename)
    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = np.reshape(test_d[:,2:-2],(len(test_d),sequence_length,1))
        predictions[day] = model.predict(test_d)[:,1] 
    return predictions    


"""
The function simulate takes as input the test_data and predictions dictionary that are output by the trainer or trained functions.

By using the argsort method of numpy, the function selects the top k predictions and the worst k predictions for each day in the predictions dictionary. In the trans_long variable, it stores the corresponding returns of the top k predictions. In the trans_short variable, the worst k predictions are stored along with the corresponding stock returns.

The mean return is then calculated for both trans_long and trans_short and stored in the rets dataframe. There are two columns in the rets dataframe, Long and Short, where Long represents the mean return for the top k predictions and Short represents the mean return for the worst k predictions.

The function returns the rets dataframe, which shows the average daily returns of the top and worst predicted stocks.
"""
def simulate(test_data,predictions):
    rets = pd.DataFrame([],columns=['Long','Short'])
    k = 10
    for day in sorted(predictions.keys()):
        preds = predictions[day]
        test_returns = test_data[test_data[:,0]==day][:,-2]
        top_preds = predictions[day].argsort()[-k:][::-1] 
        trans_long = test_returns[top_preds]
        worst_preds = predictions[day].argsort()[:k][::-1] 
        trans_short = -test_returns[worst_preds]
        rets.loc[day] = [np.mean(trans_long),np.mean(trans_short)] 
        
    return rets         

    
"""
Based on the percentage of returns, this function labels each sample in the data. A dataframe df contains the data for a particular stock, with the first column being the date and the rest being the daily stock price. Perc represents a list of two floats that represent the percentage of samples that will be labelled as "positive" and "negative".

As a first step, the function creates a list perc that includes 0 and the cumulative sum of perc. A percentage change is calculated between the current element and a previous element using the pct_change method. It creates a new dataframe with the same shape as the original, but removes the first row since there is no preceding row to compare. To each row of the new dataframe, a lambda function ranks the percentage change ascendingly and assigns a label based on the percentage range defined by perc. 0 represents the lowest percentage range and the maximum represents the highest percentage range, with the labels assigned a number from 0 to the length of perc minus 1. Due to the fact that the first row of the dataframe does not have a label, we remove it from the resulting label dataframe. It returns a dataframe with labels.
"""
def create_label(df,perc=[0.5,0.5]):
    perc = [0.]+list(np.cumsum(perc))
    label = df.iloc[:,1:].pct_change(fill_method=None)[1:].apply(
        lambda x: pd.qcut(x.rank(method='first'),perc,labels=False), axis=1)
    return label

"""
Create_stock_data is a function that takes a pandas DataFrame df and a stock st as inputs. Using the pct_change method of the DataFrame, it computes the daily percentage change of the stock price. St_data is an empty DataFrame that will contain the data for stock st.

By using a for loop that goes from 239 to 0 (i.e., in reverse order), the function adds columns to the st_data DataFrame, corresponding to past stock returns. The columns are labeled R0 to R239. In addition, it adds a column for the future return of the stock, which is the daily return shifted by one day (daily_change.shift(-1)).

A column for the data label is then added by the function. Using the create_label function, a dictionary label is computed for each stock, mapping it to a pandas Series of labels. To create the label for the stock, the label Series is appended with a NaN value.

DataFrame's Date column is retrieved from the function to add a column for data's month. A DataFrame is then split into training and test sets based on the year of the data by dropping the Month column.

This function returns two NumPy arrays: st_train_data and st_test_data. The stock st has both training and test data.
"""
def create_stock_data(df,st):
    daily_change = df[st].pct_change()
    st_data = pd.DataFrame([])
    st_data['Date'] = list(df['Date'])
    st_data['Name'] = [st]*len(st_data)
    for k in range(240)[::-1]:
        st_data['R'+str(k)] = daily_change.shift(k)
    st_data['R-future'] = daily_change.shift(-1)    
    st_data['label'] = list(label[st])+[np.nan] 
    st_data['Month'] = list(df['Date'].str[:-3])
    st_data = st_data.dropna()
    
    trade_year = st_data['Month'].str[:4]
    st_data = st_data.drop(columns=['Month'])
    st_train_data = st_data[trade_year<str(test_year)]
    st_test_data = st_data[trade_year==str(test_year)]
    return np.array(st_train_data),np.array(st_test_data)

"""
By applying StandardScaler or RobustScaler, the function Normalize normalizes the data. First, train_data is the training data for fitting the scaler, and test_data is the test data for transformation by the scaler. Normalization type is specified by norm_type.

In the first step, the function creates an instance of either StandardScaler or RobustScaler based on the norm_type argument. To calculate the scaling parameters, it calls the fit method of the scaler object. Using the transform method of the scaler object, these parameters are used to transform both training and test data. The normalized training and test data are then returned.
"""
def Normalize(train_data,test_data,norm_type='StandardScalar'):
    scaler = StandardScaler() if norm_type=='StandardScalar' else RobustScaler()
    scaler.fit(train_data[:,2:-2])
    train_data[:,2:-2] = scaler.transform(train_data[:,2:-2])
    test_data[:,2:-2] = scaler.transform(test_data[:,2:-2])

"""
An LSTM (Long Short-Term Memory) deep learning model is used in this Python script to implement a stock trading strategy. Stocks in the S&P 500 index are bought or sold based on predictions of their next day returns. During the period 1993 to 2019, the code applies this strategy on a rolling basis.

This script creates a folder for each model, and another for the results. LSTMs or CuDNNLSTMs are specified as the type of model to be used. Data normalization methods are also specified, either StandardScaler or RobustScaler.

From 1993 to 2019, the script reads in the last three years' closing prices for stocks. As a result, it creates a label for each stock indicating whether it will return a profit or a loss the following day. In the following steps, the script creates a dataset for each stock, containing the 240 previous day's returns, the future return, the label, and the date. Datasets for training and testing are then concatenated.

After the training and testing datasets are normalized, the specified normalization method is applied. Next, the LSTM model is trained using the training data. Based on the trained model's predictions, a trading strategy is implemented based on the next day's returns for the testing data.

Selecting ten of the highest-returning stocks and buying them, while simultaneously selling ten of the lowest-returning stocks, is the strategy used in the trading strategy. The mean and Sharpe ratio of the daily returns of this trading strategy are then calculated.

As a final step, the predictions and returns for each year are saved to files in the result folder, along with the mean and Sharpe ratio of the returns.
"""
model_folder = 'models-NextDay-240-1-LSTM'
result_folder = 'results-NextDay-240-1-LSTM'
for directory in [model_folder,result_folder]:
    if not os.path.exists(directory):
        os.makedirs(directory)

model_type = 'CuDNNLSTM'
norm_type = 'StandardScalar'

for test_year in range(1993,2020):
    
    print('-'*40)
    print(test_year)
    print('-'*40)
    
    filename = 'data/Close-'+str(test_year-3)+'.csv'
    df = pd.read_csv(filename)
    
    label = create_label(df)
    stock_names = list(constituents[str(test_year-1)+'-12'])
    train_data,test_data = [],[]
    
    start = time.time()
    for st in stock_names:
        st_train_data,st_test_data = create_stock_data(df,st)
        train_data.append(st_train_data)
        test_data.append(st_test_data)

    train_data = np.concatenate([x for x in train_data])
    test_data = np.concatenate([x for x in test_data])
    
    print('Created :',train_data.shape,test_data.shape,time.time()-start)
    
    sequence_length = 240
    Normalize(train_data,test_data,norm_type)
    
    predictions = trainer(train_data,test_data,model_type)
    returns = simulate(test_data,predictions)
    result = Statistics(returns.sum(axis=1))
    print('\nAverage returns prior to transaction charges')
    result.shortreport() 
    
    with open(result_folder+'/predictions-'+str(test_year)+'.pickle', 'wb') as handle:
        pickle.dump(predictions, handle, protocol=pickle.HIGHEST_PROTOCOL)
    
    returns.to_csv(result_folder+'/avg_daily_rets-'+str(test_year)+'.csv')
    with open(result_folder+"/avg_returns.txt", "a") as myfile:
        res = '-'*30 + '\n' 
        res += str(test_year) + '\n'
        res += 'Mean = ' + str(result.mean()) + '\n'
        res += 'Sharpe = '+str(result.sharpe()) + '\n'
        res += '-'*30 + '\n'
        myfile.write(res)
                

