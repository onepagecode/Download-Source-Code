"""
Pandas, numpy, random, time, pickle, scikit-learn's OneHotEncoder and RobustScaler, custom classes Statistics, TensorFlow, and relevant modules like CuDNNLSTM, Dropout, Dense, Input, add, EarlyStopping, ModelCheckpoint, ReduceLROnPlateau, CSVLogger, LearningRateScheduler, optimizers, and warnings are all imported in this code. A random seed value is also set, as well as an environment variable to ensure reproducibility.
"""
import pandas as pd
import numpy as np
import random
import time
import pickle
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import RobustScaler
from Statistics import Statistics

import tensorflow as tf
from tensorflow.keras.layers import CuDNNLSTM, Dropout,Dense,Input,add
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau, CSVLogger, LearningRateScheduler
from tensorflow.keras.models import Model, Sequential, load_model
from tensorflow.keras import optimizers
import warnings
warnings.filterwarnings("ignore")

import os
SEED = 9
os.environ['PYTHONHASHSEED']=str(SEED)
random.seed(SEED)
np.random.seed(SEED)

"""
This code loads data from a CSV file named "SPXconst.csv" and creates a dictionary called "constituents" which has keys as year-month and values as the set of companies that are constituents of the S&P 500 index in that year-month. It then creates a dictionary called "constituents_train" for the years 1993 to 2015, where each year contains a set of companies that were part of the S&P 500 index during the previous three years. A nested for loop is used to generate each year's months, which are formatted as 'YYYY-MM'. As a final step, the list of sets for each year is flattened to get a single set of all the companies that were ever constituents of the S&P 500 during the training period.
"""
SP500_df = pd.read_csv('data/SPXconst.csv')
all_companies = list(set(SP500_df.values.flatten()))
all_companies.remove(np.nan)

constituents = {'-'.join(col.split('/')[::-1]):set(SP500_df[col].dropna()) 
                for col in SP500_df.columns}

constituents_train = {} 
for test_year in range(1993,2016):
    months = [str(t)+'-0'+str(m) if m<10 else str(t)+'-'+str(m) 
              for t in range(test_year-3,test_year) for m in range(1,13)]
    constituents_train[test_year] = [list(constituents[m]) for m in months]
    constituents_train[test_year] = set([i for sublist in constituents_train[test_year] 
                                         for i in sublist])

"""

A Keras LSTM neural network model with the following architecture is defined by this function:


Each time step takes one feature from an input layer of length 240.

The CuDNNLSTM layer returns one output value for the last time step in the input sequence for each of its 25 units.

To prevent overfitting, add a dropout layer with a 0.1 dropout rate.

The probability distribution for the two classes is output by an output layer with two units and a softmax activation function.

Based on the categorical cross-entropy loss function, the RMSprop optimizer, and the accuracy metric, the model is compiled.

Returns the compiled model from the function.
"""
def makeLSTM():
    inputs = Input(shape=(240,1))
    x = CuDNNLSTM(25,return_sequences=False)(inputs)
    x = Dropout(0.1)(x)
    outputs = Dense(2,activation='softmax')(x)
    model = Model(inputs=inputs, outputs=outputs)
    model.compile(loss='categorical_crossentropy',optimizer=optimizers.RMSprop(),
                          metrics=['accuracy'])
    model.summary()
    return model
    

"""
Model_type is a string argument and its default value is 'LSTM' for the function callbacks_req. In the training process of a neural network, it returns a list of callback objects.

CSV_logger is the first callback object returned, which logs training progress in CSV. A file name is generated based on the parameters model_type and test_year.

A second callback object is model_checkpoint, which saves the best model weights after each epoch. Based on model_type and test_year, the file name is also generated.

The third and final callback object is earlyStopping, which monitors the validation loss during training and stops the training if the loss does not decrease after a certain number of epochs. During the training process, the best model's weights are also restored.

During training, the fit() method of the neural network model receives all three callback objects as a list.
"""
def callbacks_req(model_type='LSTM'):
    csv_logger = CSVLogger(model_folder+'/training-log-'+model_type+'-'+str(test_year)+'.csv')
    filepath = model_folder+"/model-" + model_type + '-' + str(test_year) + "-E{epoch:02d}.h5"
    model_checkpoint = ModelCheckpoint(filepath, monitor='val_loss',save_best_only=False, period=1)
    earlyStopping = EarlyStopping(monitor='val_loss',mode='min',patience=10,restore_best_weights=True)
    return [csv_logger,earlyStopping,model_checkpoint]

"""
reshaper(arr) reshapes a 3D numpy array with shape (n_samples, n_timesteps, n_features) into another array with shape (n_samples, n_features, n_timesteps).

The process is as follows:

np.array(np.split(arr,3,axis=1)) splits arr into three subarrays along the second axis (axis 1) and stacks them together into a new array (3, n_samples, n_timesteps, 1).

The array arr = np.swapaxes(arr,0,1) results in an array with shape (n_samples, 3, n_timesteps, 1).

The function np.swapaxes(arr,1,2) swaps the second and third axes of the array, resulting in an array with the shape (n_samples, n_timesteps, 3).

It contains the same information, but has a different arrangement than the original array. Reshaped arrays can be fed into neural networks that expect input in the form of (n_samples, n_features, n_timesteps).
"""
def reshaper(arr):
    arr = np.array(np.split(arr,3,axis=1))
    arr = np.swapaxes(arr,0,1)
    arr = np.swapaxes(arr,1,2)
    return arr

"""
Using the provided train_data, the trainer function trains a deep learning model (LSTM) and returns the trained model and its predictions on test_data.

In order to perform the function, follow these steps:

To randomize the sample order, shuffle the train_data.

Train_data should be separated into inputs (features) and outputs (labels).

Shape the inputs into a 3D tensor of shape (num_samples, 240, 1), where num_samples is the number of samples in train_data. It is necessary to reshape the input shape because LSTM requires a 3D input shape with dimensions (batch_size, timesteps, features).

Use the OneHotEncoder in sklearn.preprocessing to encode the labels one-at-a-time. Due to the fact that there are two classes, the output labels will have the shape (num_samples, 2).

Train_ret array should have an extra column of zeros at the beginning.

The makeLSTM function creates an LSTM instance.

Monitor the model's training progress by creating a list of callbacks.

Fit the model to the train_x and enc_y data, with 20% of the data being used for validation. Models are trained with 1000 epochs and 512 batches.

Using the trained LSTM model, predict the probability of the positive class for each unique date in test_data.

Provide the trained LSTM model and its predictions based on the test data.
"""
def trainer(train_data,test_data,model_type='LSTM'):
    np.random.shuffle(train_data)
    train_x,train_y,train_ret = train_data[:,2:-2],train_data[:,-1],train_data[:,-2]
    train_x = np.reshape(train_x,(len(train_x),240,1))
    train_y = np.reshape(train_y,(-1, 1))
    train_ret = np.reshape(train_ret,(-1, 1))
    enc = OneHotEncoder(handle_unknown='ignore')
    enc.fit(train_y)
    enc_y = enc.transform(train_y).toarray()
    train_ret = np.hstack((np.zeros((len(train_data),1)),train_ret)) 

    if model_type == 'LSTM':
        model = makeLSTM()
    else:
        return
    callbacks = callbacks_req(model_type)
    
    model.fit(train_x,
              enc_y,
              epochs=1000,
              validation_split=0.2,
              callbacks=callbacks,
              batch_size=512
              )

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = np.reshape(test_d[:,2:-2], (len(test_d),240,1))
        predictions[day] = model.predict(test_d)[:,1]
    return model,predictions

"""
The function loads a trained model from a saved file and generates predictions based on the test data. Both the train and test data, as well as the filename of the saved model, are input.

Firstly, it loads the model using the Keras load_model function. Then, it creates an empty dictionary of predictions. For each unique date in the test data, it subsets the data, reshapes it to the appropriate input shape (240 timesteps x 1 feature), and uses the trained model to predict a positive return. With the date as the key, these predictions are stored in the predictions dictionary. Lastly, the function returns the trained model and the predictions dictionary.
"""
def trained(filename,train_data,test_data):
    model = load_model(filename)

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = np.reshape(test_d[:,2:-2],(len(test_d),240,1))
        predictions[day] = model.predict(test_d)[:,1]
    return model,predictions     

"""
Based on the model predictions, this function simulates a trading strategy. As inputs, it takes the test data and the predictions for each day. Every day, it calculates the mean returns for long and short positions on the top 10 and worst 10 predicted stocks. Lastly, it returns a dataframe with the long and short returns for each day as well as their mean.
"""
def simulate(test_data,predictions):
    rets = pd.DataFrame([],columns=['Long','Short'])
    k = 10
    for day in sorted(predictions.keys()):
        preds = predictions[day]
        test_returns = test_data[test_data[:,0]==day][:,-2]
        top_preds = predictions[day].argsort()[-k:][::-1] 
        trans_long = test_returns[top_preds]
        worst_preds = predictions[day].argsort()[:k][::-1] 
        trans_short = -test_returns[worst_preds]
        rets.loc[day] = [np.mean(trans_long),np.mean(trans_short)] 
    print('Result : ',rets.mean())  
    return rets       

    
"""
Two pandas dataframes df_open and df_close are passed to the function create_label. Both dataframes should have the same date index and the same number of columns. For each column, the function calculates the percentage rank of the returns (difference between closing and opening prices divided by opening price). As a result, the percentage ranks are binned into equal size bins based on the input argument perc, which is a list of floats between 0 and 1. Bins are created based on the rank of the returns, with the first bin starting at rank 0, the second bin starting at the rank corresponding to the first element in perc, and so on. A pandas dataframe with the same shape as df_open and df_close, but with integer labels corresponding to the bins in place of the returns. A label cannot be created for the first row of the returned dataframe.
"""
def create_label(df_open,df_close,perc=[0.5,0.5]):
    if not np.all(df_close.iloc[:,0]==df_open.iloc[:,0]):
        print('Date Index issue')
        return
    perc = [0.]+list(np.cumsum(perc))
    label = (df_close.iloc[:,1:]/df_open.iloc[:,1:]-1).apply(
            lambda x: pd.qcut(x.rank(method='first'),perc,labels=False), axis=1)
    return label[1:]

"""
There are three arguments that have to be passed to the function created_stock_data in this code:

Pandas DataFrame containing the open prices of stocks for a certain period

The closing price of each stock for the same period as df_open is contained in df_close, a pandas DataFrame

St: a string indicating the stock ticker for which data will be generated.

First, the function creates an empty pandas DataFrame called st_data to hold the stock data. The columns in st_data include the date, the name of the stock (st), the intraday returns for each of the past m days (m is set to 240), the intraday return for the next day, a label to indicate whether the next-day intraday return is in the top 50% or bottom 50% of intraday returns for that stock, and a month (derived from the date).

By shifting the data by k days (from m-1 to 0), the function calculates the stock's intraday return for the past m days, using the closing price and open price data in df_open and df_close, respectively. To create a time series of intraday returns over m days, this is done.

By shifting the intraday return for the stock by -1 day, the function calculates the intraday return for the next day. A label is also assigned to each row of the DataFrame informing whether the intraday return for the next day is in the top 50% or bottom 50% of intraday returns for that stock. By calling the function create_label, this label is created.

The function then removes any rows with missing values, separates the data into training and testing sets based on the trading year, and returns the training and testing data as numpy arrays.
"""
def create_stock_data(df_open,df_close,st,m=240):
    st_data = pd.DataFrame([])
    st_data['Date'] = list(df_close['Date'])
    st_data['Name'] = [st]*len(st_data)
    daily_change = df_close[st]/df_open[st]-1
    for k in range(m)[::-1]:
        st_data['IntraR'+str(k)] = daily_change.shift(k)

    st_data['IntraR-future'] = daily_change.shift(-1)    
    st_data['label'] = list(label[st])+[np.nan] 
    st_data['Month'] = list(df_close['Date'].str[:-3])
    st_data = st_data.dropna()
    
    trade_year = st_data['Month'].str[:4]
    st_data = st_data.drop(columns=['Month'])
    st_train_data = st_data[trade_year<str(test_year)]
    st_test_data = st_data[trade_year==str(test_year)]
    return np.array(st_train_data),np.array(st_test_data) 

"""
For a financial time-series analysis problem, the scalar_normalize function takes two numpy arrays as input: train_data and test_data. First, it creates an instance of RobustScaler that scales the features of the data in the 2nd to 2nd last columns of train_data and test_data. The scaler object is then fitted to the training data and the scaling transformation is applied to both the training and test data. The scaled values are then updated in the respective columns of train_data and test_data. As a result of the function, the train_data and test_data arrays are modified in-place without returning anything.
"""
def scalar_normalize(train_data,test_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:,2:-2])
    train_data[:,2:-2] = scaler.transform(train_data[:,2:-2])
    test_data[:,2:-2] = scaler.transform(test_data[:,2:-2])
    

"""
If they do not exist, this code creates two directories named models-Intraday-240-1-LSTM and results-Intraday-240-1-LSTM. First, model_folder and result_folder are initialized with the names of the two directories. Using the os module, we check if each directory exists in the current working directory, and if not, we create it using the os.makedirs() function. Before any files or results are saved, the program ensures that the directories exist.
"""
model_folder = 'models-Intraday-240-1-LSTM'
result_folder = 'results-Intraday-240-1-LSTM'
for directory in [model_folder,result_folder]:
    if not os.path.exists(directory):
        os.makedirs(directory)

"""
The code iterates over the years 1993 through 2019. The following is done for each year:

It reads two CSV files containing daily opening and closing prices for all S&P500 stocks for the past three years.

Creates labels for each stock based on daily returns using the function create_label().

The create_stock_data() function generates a dataframe with columns for daily returns for the past 240 days and the next day's return for each stock. Columns for labels and months are also added.

By using the scalar_normalize() function, all train and test data are concatenated into a single array.

Trains an LSTM model on the train data and makes predictions for the test data using the trainer() function.

Calculates the average daily return by simulating trades based on the model predictions.

Prints the average daily returns to a file.
"""
for test_year in range(1993,2020):
    
    print('-'*40)
    print(test_year)
    print('-'*40)
    
    filename = 'data/Open-'+str(test_year-3)+'.csv'
    df_open = pd.read_csv(filename)
    filename = 'data/Close-'+str(test_year-3)+'.csv'
    df_close = pd.read_csv(filename)
    
    label = create_label(df_open,df_close)
    stock_names = sorted(list(constituents[str(test_year-1)+'-12']))
    train_data,test_data = [],[]

    start = time.time()
    for st in stock_names:
        st_train_data,st_test_data = create_stock_data(df_open,df_close,st)
        train_data.append(st_train_data)
        test_data.append(st_test_data)
        
    train_data = np.concatenate([x for x in train_data])
    test_data = np.concatenate([x for x in test_data])
    
    scalar_normalize(train_data,test_data)
    print(train_data.shape,test_data.shape,time.time()-start)
    
    model,predictions = trainer(train_data,test_data)
    returns = simulate(test_data,predictions)
    returns.to_csv(result_folder+'/avg_daily_rets-'+str(test_year)+'.csv')
    
    result = Statistics(returns.sum(axis=1))
    print('\nAverage returns prior to transaction charges')
    result.shortreport() 
    
    with open(result_folder+"/avg_returns.txt", "a") as myfile:
        res = '-'*30 + '\n'
        res += str(test_year) + '\n'
        res += 'Mean = ' + str(result.mean()) + '\n'
        res += 'Sharpe = '+str(result.sharpe()) + '\n'
        res += '-'*30 + '\n'
        myfile.write(res)
        

