"""
For reproducibility, this code imports necessary packages and sets the random seed to a fixed value.

Pandas is a library for manipulating and analyzing data.
Numpy provides support for multi-dimensional arrays and matrices in scientific computing.
Random generates pseudo-random numbers.
The time module provides various functions related to time.
Pickle serializes and de-serializes Python objects.
The OneHotEncoder class from sklearn.preprocessing encodes categorical integer features as one-hot numeric arrays.
The Statistics module contains functions for calculating statistical measures of returns.
A random forest model is built using the RandomForestClassifier class from sklearn.ensemble.
The os module provides functionality dependent on the operating system.
SEED is set to 9 as is PYTHONHASHSEED in the environment. To ensure the same random numbers are generated every time the code is run, random.seed() and np.random.seed() are set to the same value. In order to ensure reproducibility, this is done.
"""
import pandas as pd
import numpy as np
import random
import time
import pickle
from sklearn.preprocessing import OneHotEncoder
from Statistics import Statistics
from sklearn.ensemble import RandomForestClassifier

import os
SEED = 9
os.environ['PYTHONHASHSEED']=str(SEED)
random.seed(SEED)
np.random.seed(SEED)

"""
A CSV file containing constituent data for the S&P 500 is read in and preprocessed to create dictionaries of constituents for each year between 1993 and 2015.

As a first step, a CSV file is read in and the resulting DataFrame is stored in the SP500_df variable using the pd.read_csv() function. Using the values.flatten() method, the DataFrame is flattened into a list and any nan values are removed.

The code then creates a dictionary called constituents, which maps each date in the SP500_df DataFrame to a set of companies that were constituents of the S&P 500 on that date. To reverse the order of the year and month components of each column name, a dictionary comprehension iterates over the columns in the SP500_df DataFrame and applies the col.split('/')[::-1] method. A constituents dictionary is created by joining the reversed date strings with hyphens using '-'.join(). Dropna() is called on the SP500_df DataFrame for each key to obtain a Series of company names, which is then converted to a set using the set() method.

Last but not least, the code creates a dictionary called constituents_train that maps every year between 1993 and 2015 to a set of companies that were constituents of the S&P 500 during those three years. Using a nested loop, another dictionary comprehension iterates over the range of years and creates a list of month strings for each year. Using an if statement and the str() function, month strings are created by concatenating the year with a month number. List comprehension and the set() function are used to convert the resulting month strings into sets of individual company names based on the constituents dictionary.
"""
SP500_df = pd.read_csv('data/SPXconst.csv')
all_companies = list(set(SP500_df.values.flatten()))
all_companies.remove(np.nan)

constituents = {'-'.join(col.split('/')[::-1]):set(SP500_df[col].dropna()) 
                for col in SP500_df.columns}

constituents_train = {} 
for test_year in range(1993,2016):
    months = [str(t)+'-0'+str(m) if m<10 else str(t)+'-'+str(m) 
              for t in range(test_year-3,test_year) for m in range(1,13)]
    constituents_train[test_year] = [list(constituents[m]) for m in months]
    constituents_train[test_year] = set([i for sublist in constituents_train[test_year] for i in sublist])
 

"""
A Random Forest classifier is trained on the train_data using the trainer function, which takes in train_data and test_data. The function first sets the seed value for numpy's and random modules' random number generators. This ensures that the same sequence of random numbers is generated every time the function is called. The labels and features for training are then extracted from the train_data array, and the labels are cast to integers.

Using the RandomForestClassifier() function from scikit-learn, the function then creates a Random Forest classifier with 1000 decision trees and a maximum depth of 20. For reproducibility, random_state is set to the same seed value as before, and n_jobs is set to -1 to use all CPUs.

In order to train the Random Forest classifier, the clf.fit() method is called on the training data. In order to determine whether a trained model is accurate based on the training data, the score() method is used.

Using the predict_proba() method of the Random Forest classifier, the function creates a dictionary of predictions where each key represents a date in the test set, and each value represents a probability array output by the trained model.
"""
def trainer(train_data,test_data):
    random.seed(SEED)
    np.random.seed(SEED)
    
    train_x,train_y = train_data[:,2:-2],train_data[:,-1]
    train_y = train_y.astype('int')

    print('Started training')
    clf = RandomForestClassifier(n_estimators=1000, max_depth=20, random_state = SEED, n_jobs=-1)
    clf.fit(train_x,train_y)
    print('Completed ',clf.score(train_x,train_y))

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = test_d[:,2:-2] 
        predictions[day] = clf.predict_proba(test_d)[:,1]
    return predictions


"""
The code defines a function called simulate that takes two arguments: test_data and predictions.

Test_data is a numpy array containing daily stock return data. Each row represents a single day's worth of data, and each column represents a specific value, such as a stock's daily return or the date.

For each day in the test_data, the predictions argument contains the probability of each stock going up in price. In the dictionary, keys are the dates for which predictions were made, and values are numpy arrays containing the predicted probabilities for each stock.

An empty pandas DataFrame called rets is first created with two columns labeled 'Long' and 'Short'. It then loops over each day in the predictions dictionary in ascending order. Each day's return data is extracted from the test_data array for that day. By analyzing the predicted probabilities for that day, it determines which stocks to buy and which stocks to sell. This code sets k to 10. A new row of the rets DataFrame is created by calculating the average daily return of the top k stocks and the bottom k stocks. At the end of the function, the rets DataFrame is returned.
"""
def simulate(test_data,predictions):
    rets = pd.DataFrame([],columns=['Long','Short'])
    k = 10
    for day in sorted(predictions.keys()):
        preds = predictions[day]
        test_returns = test_data[test_data[:,0]==day][:,-2]
        top_preds = predictions[day].argsort()[-k:][::-1] 
        trans_long = test_returns[top_preds]
        worst_preds = predictions[day].argsort()[:k][::-1] 
        trans_short = -test_returns[worst_preds]
        rets.loc[day] = [np.mean(trans_long),np.mean(trans_short)] 
    return rets   
    
"""
A dataset's labels are created by this function create_label(). A dataframe df is input, along with an optional argument perc. Using the distribution of the returns, this function labels each row of the input dataframe.

A list of percentiles is generated from perc using np.cumsum(). With pd.qcut(), the returns are divided into equally sized quantiles using the percentiles. In order to obtain integer values as labels, the labels argument must be set to False.

Upon calling the function, a Pandas dataframe containing integer labels for each row of the input dataframe is returned. Quantile labels indicate which row belongs to which quantile.
"""
def create_label(df,perc=[0.5,0.5]):
    perc = [0.]+list(np.cumsum(perc))
    label = df.iloc[:,1:].pct_change(fill_method=None)[1:].apply(
        lambda x: pd.qcut(x.rank(method='first'),perc,labels=False), axis=1)
    return label

"""
In this code, a function called create_stock_data is defined that takes a DataFrame df and a string st as inputs. The function creates a new DataFrame st_data with columns for the date, stock name, historical returns, future returns, labels, and month.

Using a for loop, historical returns are calculated by iterating over a list of integers ranging from 1 to 20 and then 40 to 240. In the loop, the function calculates the percentage change in the stock price over the past k days and stores it in the 'Rk' column of st_data.

A column of st_data labeled 'R-future' stores the future returns as a percentage change in stock price from one day to the next.

Using a previously defined function called create_label, the function also assigns labels to each row of st_data. Calculates the percentage change in stock price between each day, ranks them, and labels each day according to its quartile.

Lastly, the function drops any rows with missing values and separates the data by year into training and testing sets. The training set contains data from years prior to test_year, and the testing set contains data from test_year. Training and testing sets are returned as numpy arrays by the function.
"""
def create_stock_data(df,st):
    st_data = pd.DataFrame([])
    st_data['Date'] = list(df['Date'])
    st_data['Name'] = [st]*len(st_data)
    for k in list(range(1,21))+list(range(40,241,20)):
        st_data['R'+str(k)] = df[st].pct_change(k)
    st_data['R-future'] = df[st].pct_change().shift(-1)    
    st_data['label'] = list(label[st])+[np.nan] 
    st_data['Month'] = list(df['Date'].str[:-3])
    st_data = st_data.dropna()
    
    trade_year = st_data['Month'].str[:4]
    st_data = st_data.drop(columns=['Month'])
    st_train_data = st_data[trade_year<str(test_year)]
    st_test_data = st_data[trade_year==str(test_year)]
    return np.array(st_train_data),np.array(st_test_data)

"""
Using the random forest algorithm, this script predicts stock returns for companies in the S&P 500. Iterating over the years from 1993 to 2019, the script reads the close price data for the previous three years and creates a label for each stock according to its percentiles. Based on the training data (previous years' data), a random forest classifier is trained and used to predict the test data (the current year's data). Lastly, it calculates the average daily returns for the top k and bottom k predictions.

In the first line of code, we define the output folder and create it if it doesn't exist. Iterating over the years 1993 to 2019, it reads the close price data for the previous three years, creates labels based on percentiles of returns, and creates train and test data. A random forest classifier is then trained on the training data and predicted based on the test data by the function trainer. The top k and bottom k predictions are then calculated by calling the function simulate. Upon receiving the results, the Sharpe ratio and mean of the returns are written to a file.
"""
result_folder = 'results-NextDay-240-1-RF'
for directory in [result_folder]:
    if not os.path.exists(directory):
        os.makedirs(directory)

for test_year in range(1993,2020):
    
    print('-'*40)
    print(test_year)
    print('-'*40)
    
    filename = 'data/Close-'+str(test_year-3)+'.csv'
    df = pd.read_csv(filename)
    
    label = create_label(df)
    stock_names = sorted(list(constituents[str(test_year-1)+'-12']))
    train_data,test_data = [],[]
    
    start = time.time()
    for st in stock_names:
        st_train_data,st_test_data = create_stock_data(df,st)
        train_data.append(st_train_data)
        test_data.append(st_test_data)

    train_data = np.concatenate([x for x in train_data])
    test_data = np.concatenate([x for x in test_data])
    
    print('Created :',train_data.shape,test_data.shape,time.time()-start)
    
    
    predictions = trainer(train_data,test_data)
    returns = simulate(test_data,predictions)
    result = Statistics(returns.sum(axis=1))
    print('\nAverage returns prior to transaction charges')
    result.shortreport() 
    
    with open(result_folder+'/predictions-'+str(test_year)+'.pickle', 'wb') as handle:
        pickle.dump(predictions, handle, protocol=pickle.HIGHEST_PROTOCOL)
    
    returns.to_csv(result_folder+'/avg_daily_rets-'+str(test_year)+'.csv')
    with open(result_folder+"/avg_returns.txt", "a") as myfile:
        res = '-'*30 + '\n' 
        res += str(test_year) + '\n'
        res += 'Mean = ' + str(result.mean()) + '\n'
        res += 'Sharpe = '+str(result.sharpe()) + '\n'
        res += '-'*30 + '\n'
        myfile.write(res)
