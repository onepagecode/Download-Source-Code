"""
In this block of code, necessary modules are imported and random seeds are set to ensure reproducibility. Numpy is used for numerical computing, while pandas is used for data analysis and manipulation. For generating random numbers, the random module is used, and for timing, the time module is used. For serializing and de-serializing Python objects, the pickle module is used. A random forest model is trained using the RandomForestClassifier class in the sklearn module. A custom module contains the Statistics class. The random seeds for numpy and random are both set to 9 for consistency, as is the PYTHONHASHSEED environment variable.
"""
import pandas as pd
import numpy as np
import random
import time
import pickle
from sklearn.ensemble import RandomForestClassifier
from Statistics import Statistics

import os
SEED = 9
os.environ['PYTHONHASHSEED']=str(SEED)
random.seed(SEED)
np.random.seed(SEED)

"""
SPXconst.csv contains information about companies in the S&P 500 index at different points in time, which is read by this code.

SP500_df is a pandas DataFrame created by reading the file and storing it.

By flattening the DataFrame and removing NaN values, the second line creates a list of all companies.

The third line creates a dictionary called constituents that maps the year-month string of the DataFrame columns to the company names that are constituents of that month. Before creating the set, the code removes any NaN values from the column using the set function.

From the fourth to the eleventh lines, this dictionary is used to create a new dictionary called constituents_train, which maps each year from 1993 to 2015 to a set of all companies that were constituents in any month of the three preceding years. From the three previous years, the code generates a list of month strings for each year, extracts the companies corresponding to each string from the constituents dictionary, flattens the resulting lists of sets, removes duplicate companies, and saves the result as a dictionary set.

This code creates a dictionary of all companies that are constituents of the S&P 500 index in the three years prior to each test year. Data from the appropriate Open and Close CSV files is extracted later using this dictionary.
"""
SP500_df = pd.read_csv('data/SPXconst.csv')
all_companies = list(set(SP500_df.values.flatten()))
all_companies.remove(np.nan)

constituents = {'-'.join(col.split('/')[::-1]):set(SP500_df[col].dropna()) 
                for col in SP500_df.columns}

constituents_train = {} 
for test_year in range(1993,2016):
    months = [str(t)+'-0'+str(m) if m<10 else str(t)+'-'+str(m) 
              for t in range(test_year-3,test_year) for m in range(1,13)]
    constituents_train[test_year] = [list(constituents[m]) for m in months]
    constituents_train[test_year] = set([i for sublist in constituents_train[test_year] 
                                         for i in sublist])
    
"""
Trainer is a function that trains a random forest model on training data and makes predictions on test data using the provided training data.

There are two arguments to the function: train_data and test_data. The rows represent the features, while the columns represent the labels.

To ensure reproducibility, the function sets the random seed to a fixed value at the beginning. The train_data array is then used to extract features and labels. A datatype of integer is assigned to the label column.

A RandomForestClassifier instance is then created with the following hyperparameters:

There are n_estimators in the forest.

Decision trees can have a maximum depth of max_depth

The random seed used by the classifier is random_state

In parallel processing, n_jobs specifies how many CPU cores to use (set to -1 for all cores to be used).

Based on the training data, the function fits a random forest classifier and prints its score.

A dictionary predictions is then created and initialized based on the unique dates extracted from the test data so that the classifier can store its predictions for each unique date.

Using the predict_proba method of the random forest classifier, the function makes predictions for each date in the test data. For each date, the predicted probabilities of the positive class are stored in the predictions dictionary.

This function returns a dictionary of predictions.
"""
def trainer(train_data,test_data):
    random.seed(SEED)
    np.random.seed(SEED)
    
    train_x,train_y = train_data[:,2:-2],train_data[:,-1]
    train_y = train_y.astype('int')

    print('Started training')
    clf = RandomForestClassifier(n_estimators=1000,
                                 max_depth=10, 
                                 random_state = SEED,
                                 n_jobs=-1)
    clf.fit(train_x,train_y)
    print('Completed ',clf.score(train_x,train_y))

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = test_d[:,2:-2] 
        predictions[day] = clf.predict_proba(test_d)[:,1]
    return predictions


"""
Test_data and predictions are the arguments to a function called simulate in this code.

A NumPy array containing test data for a particular year is passed as the test_data argument. There are four columns in this table: date, stock name, intraday returns for the last 240 minutes, intraday future returns, and label.

There is an array of predicted probabilities of positive intraday future returns for each stock in the predictions argument, which is a dictionary with keys of dates.

An empty Pandas DataFrame called rets is created first with columns for long and short returns. This function then finds the top 10 and bottom 10 stocks with the highest predicted probabilities of positive intraday returns for each day in the predictions dictionary. In the rets DataFrame for that day, it calculates the mean intraday future returns for the top 10 stocks (long position) and the bottom 10 stocks (short position).

As a final result, rets DataFrame is returned by this function.
"""
def simulate(test_data,predictions):
    rets = pd.DataFrame([],columns=['Long','Short'])
    k = 10
    for day in sorted(predictions.keys()):
        preds = predictions[day]
        test_returns = test_data[test_data[:,0]==day][:,-2]
        top_preds = predictions[day].argsort()[-k:][::-1] 
        trans_long = test_returns[top_preds]
        worst_preds = predictions[day].argsort()[:k][::-1] 
        trans_short = -test_returns[worst_preds]
        rets.loc[day] = [np.mean(trans_long),np.mean(trans_short)] 
    return rets   
    
"""
Create_label is a function that takes as input two pandas dataframes, df_open and df_close, and an optional list of labels. First, the function compares the dates of the two dataframes. If the dates align, the function divides the closing prices by the opening prices and subtracts 1. Following that, pd.qcut is used to rank the daily returns and quantile breakpoints are calculated based on the input perc. By returning the rank for each stock, the function returns its performance label.

For each stock's daily returns, create_label creates a ranking based on their quantiles, which can be used as a classification label for training a machine learning algorithm.
"""
def create_label(df_open,df_close,perc=[0.5,0.5]):
    if not np.all(df_close.iloc[:,0]==df_open.iloc[:,0]):
        print('Date Index issue')
        return
    perc = [0.]+list(np.cumsum(perc))
    label = (df_close.iloc[:,1:]/df_open.iloc[:,1:]-1).apply(
            lambda x: pd.qcut(x.rank(method='first'),perc,labels=False), axis=1)
    return label

"""
Create_stock_data takes two dataframes containing stock prices (df_close and df_open) and a stock name (st). In the next step, it creates a new dataframe st_data containing the stock data for the given stock. By using df_close[st]/df_open[st]-1, the function calculates the daily percentage change of the stock and stores it in the variable daily_change.

Next, it creates a list of integers m that represent the number of minutes in the past to include as features. IntraRk represents the change in stock price between df_open[st] k minutes ago and df_close[st] today. Each value of k in m is assigned to a new column in st_data.

Additionally, the function creates a column R-future in st_data containing the daily percentage change of the stock. Based on the daily percentage change of the stock, the function adds a new column label to st_data containing the label (0, 1, or 2) for each day.

The function returns numpy arrays containing training and testing data for each year, separated by the year of data.
"""
def create_stock_data(df_close,df_open,st):
    st_data = pd.DataFrame([])
    st_data['Date'] = list(df_close['Date'])
    st_data['Name'] = [st]*len(st_data)
    
    daily_change = df_close[st]/df_open[st]-1
    m = list(range(1,20))+list(range(20,241,20))
    for k in m:
        st_data['IntraR'+str(k)] = df_close[st].shift(1)/df_open[st].shift(k)-1
        
    st_data['R-future'] = daily_change 
    st_data['label'] = list(label[st]) 
    st_data['Month'] = list(df_close['Date'].str[:-3])
    st_data = st_data.dropna()
    
    trade_year = st_data['Month'].str[:4]
    st_data = st_data.drop(columns=['Month'])
    st_train_data = st_data[trade_year<str(test_year)]
    st_test_data = st_data[trade_year==str(test_year)]
    return np.array(st_train_data),np.array(st_test_data)

"""
In the code above, a variable called result_folder is initialized and a directory named result_folder is created if it does not already exist. As the program iterates over the years from 1993 to 2019, it reads in the stock data for each year and creates labels for the data using the create_label function. Following that, the create_stock_data function is called to create train and test data for each stock. Using the trainer function, it calculates predictions for the test data based on the train data after concatenating the results from the list. The average returns for the predictions are then computed using the simulate function and saved in a csv file along with the average returns for each year. A pickle file is then saved with the predictions.
"""
result_folder = 'results-Intraday-240-1-RF'
for directory in [result_folder]:
    if not os.path.exists(directory):
        os.makedirs(directory)

for test_year in range(1993,2020):
    
    print('-'*40)
    print(test_year)
    print('-'*40)
    
    filename = 'data/Open-'+str(test_year-3)+'.csv'
    df_open = pd.read_csv(filename)
    filename = 'data/Close-'+str(test_year-3)+'.csv'
    df_close = pd.read_csv(filename)
    
    label = create_label(df_open,df_close)
    stock_names = sorted(list(constituents[str(test_year-1)+'-12']))
    train_data,test_data = [],[]
    
    start = time.time()
    for st in stock_names:
        st_train_data,st_test_data = create_stock_data(df_close,df_open,st)
        train_data.append(st_train_data)
        test_data.append(st_test_data)

    train_data = np.concatenate([x for x in train_data])
    test_data = np.concatenate([x for x in test_data])
    
    print('Created :',train_data.shape,test_data.shape,time.time()-start)
    
    predictions = trainer(train_data,test_data)
    returns = simulate(test_data,predictions)
    result = Statistics(returns.sum(axis=1))
    print('\nAverage returns prior to transaction charges')
    result.shortreport() 
    
    with open(result_folder+'/predictions-'+str(test_year)+'.pickle', 'wb') as handle:
        pickle.dump(predictions, handle, protocol=pickle.HIGHEST_PROTOCOL)
    
    returns.to_csv(result_folder+'/avg_daily_rets-'+str(test_year)+'.csv')
    with open(result_folder+"/avg_returns.txt", "a") as myfile:
        res = '-'*30 + '\n' 
        res += str(test_year) + '\n'
        res += 'Mean = ' + str(result.mean()) + '\n'
        res += 'Sharpe = '+str(result.sharpe()) + '\n'
        res += '-'*30 + '\n'
        myfile.write(res)
            
