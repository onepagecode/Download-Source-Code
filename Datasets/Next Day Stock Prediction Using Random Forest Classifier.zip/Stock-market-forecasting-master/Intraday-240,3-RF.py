"""
The code above imports the necessary libraries and sets a random seed for reproducibility. Pandas is used to manipulate data, numpy is used to perform numerical computations, random is used to generate random numbers, time is used to measure the elapsed time, pickle is used to store the model and results, and RandomForestClassifier is used to build a random forest classifier from scikit-learn. To evaluate the performance of the trading strategy, it also imports the Statistics class from Statistics.py. To ensure reproducibility, it sets a random seed.
"""
import pandas as pd
import numpy as np
import random
import time
import pickle
from sklearn.ensemble import RandomForestClassifier
from Statistics import Statistics

import os
SEED = 9
os.environ['PYTHONHASHSEED']=str(SEED)
random.seed(SEED)
np.random.seed(SEED)

"""
In this block of code, the constituents of the S&P 500 index are read from the file 'data/SPXconst.csv'. The resulting data frame is stored in the variable SP500_df using the pandas function read_csv().

After flattening the SP500_df data frame and removing any NaN values, the code creates a list of all the S&P 500 companies.

Constituents is a dictionary with years as keys and S&P 500 index constituents as values. It is constructed by iterating over the columns of SP500_df, splitting the column names (which are in the format 'MM/YYYY') and reversing them, then creating a set of non-null values. In the constituents dictionary, the resulting sets are stored as values, with the corresponding years as keys.

Constituents_train is another dictionary with the training set's S&P 500 index constituents as keys and the corresponding years as values. For each year from 1993 to 2015, iterate over the months from three years prior to that year up to the previous year, and add the corresponding S&P 500 index constituents. To create the final constituents for the training set for that year, the list is flattened and duplicates are removed.
"""
SP500_df = pd.read_csv('data/SPXconst.csv')
all_companies = list(set(SP500_df.values.flatten()))
all_companies.remove(np.nan)

constituents = {'-'.join(col.split('/')[::-1]):set(SP500_df[col].dropna()) 
                for col in SP500_df.columns}

constituents_train = {} 
for test_year in range(1993,2016):
    months = [str(t)+'-0'+str(m) if m<10 else str(t)+'-'+str(m) 
              for t in range(test_year-3,test_year) for m in range(1,13)]
    constituents_train[test_year] = [list(constituents[m]) for m in months]
    constituents_train[test_year] = set([i for sublist in constituents_train[test_year] 
                                         for i in sublist])
    
"""
Trainer() is a function that takes two arguments, train_data and test_data. To ensure reproducibility, the function first sets the seed for the random number generator. From train_data, it extracts the input features and target variable. All columns except the last two are input features, while the last column is the target variable. Cast the target variable to an integer data type.

A RandomForestClassifier object is then created and some parameters are set. It sets the number of decision trees in the forest to 1000, the maximum depth of each tree to 10, and the number of jobs to run in parallel to -1 (i.e., to use all processors). In the next step, the function fits the classifier to the training data and prints out the training score.

The function then creates a dictionary prediction that holds the predicted probabilities of positive returns for each day in the test data. A trained classifier uses the predict_proba() method to predict the probability that a positive return will occur for each unique date in the test data. In the predictions dictionary, the predicted probabilities are stored under the date key. It returns a dictionary of predictions.
"""
def trainer(train_data,test_data):
    random.seed(SEED)
    np.random.seed(SEED)
    
    train_x,train_y = train_data[:,2:-2],train_data[:,-1]
    train_y = train_y.astype('int')

    print('Started training')
    clf = RandomForestClassifier(n_estimators=1000, 
        max_depth=10, 
        random_state = SEED, 
        n_jobs=-1)
    clf.fit(train_x,train_y)
    print('Completed ',clf.score(train_x,train_y))

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = test_d[:,2:-2] 
        predictions[day] = clf.predict_proba(test_d)[:,1]
    return predictions


"""
Simulate takes in test_data, which is a numpy array, and predictions, which is a dictionary containing the model predictions for each day in the test data. After that, it creates two columns called 'Long' and 'Short' in a pandas DataFrame called rets. Then, k is initialized to 10.

In the predictions dictionary, the function loops through the sorted keys (dates). From the test_data array, it retrieves the actual test_returns for each date. Sorting the predictions array in ascending and descending order identifies the top k predictions with the highest probability of increasing and the worst k predictions with the highest probability of decreasing. Trans_long and trans_short store the returns for the top k and worst k stocks, respectively. As a final step, the mean of the trans_long and trans_short arrays is computed and added to the rets DataFrame for that day.

After that, the function returns the rets DataFrame, which contains the average daily returns for the top k and worst k stocks selected by the model for each day.
"""
def simulate(test_data,predictions):
    rets = pd.DataFrame([],columns=['Long','Short'])
    k = 10
    for day in sorted(predictions.keys()):
        preds = predictions[day]
        test_returns = test_data[test_data[:,0]==day][:,-2]
        top_preds = predictions[day].argsort()[-k:][::-1] 
        trans_long = test_returns[top_preds]
        worst_preds = predictions[day].argsort()[:k][::-1] 
        trans_short = -test_returns[worst_preds]
        rets.loc[day] = [np.mean(trans_long),np.mean(trans_short)] 
    return rets   
    
"""
Machine learning models are labeled using the create_label function. A particular stock's opening and closing prices are represented by two pandas dataframes df_open and df_close. In addition, the function takes a list of percs specifying the quantile percentages to divide the stock price returns by.

If df_open and df_close do not match, the function prints an error message and returns. Next, it creates a list perc of quantile percentages by appending 0 to the beginning and computing the cumulative sum.

By dividing the closing price by the opening price and subtracting 1, the function computes the stock price returns. Using the quantile percentages in perc, it computes the quantile bins for each row of the returns dataframe. Labels=False in pd.qcut returns bin numbers instead of bin labels.

Last but not least, the function returns a label array with the same dimensions as the df_close dataframe except for the first row.
"""
def create_label(df_open,df_close,perc=[0.5,0.5]):
    if not np.all(df_close.iloc[:,0]==df_open.iloc[:,0]):
        print('Date Index issue')
        return
    perc = [0.]+list(np.cumsum(perc))
    label = (df_close.iloc[:,1:]/df_open.iloc[:,1:]-1).apply(
            lambda x: pd.qcut(x.rank(method='first'),perc,labels=False), axis=1)
    return label

"""
DF_close, DF_open, and st are input parameters for the create_stock_data function. Different stocks' closing and opening prices are represented by df_close and df_open, respectively, while stocks' names are represented by st. As a result, a pandas DataFrame st_data is created to store the stock data.

st_data contains two columns, one for the date and another for the stock name. In daily_change, the function calculates the daily changes in price based on the closing and opening prices of the stock.

The function then generates a list m containing 19 integers ranging from 1 to 19 and multiples of 20 ranging from 20 to 240. After that, it creates columns in st_data for intra-day returns for each integer in m using the shift() method. For each integer in m, it creates columns for the closing returns and overnight returns using the pct_change() method.

Next, the function creates two more columns in st_data - R-future, which represents the daily change in price for the next day, and label, which represents the categorical label assigned to each day. Using the percentiles specified in the perc parameter (default: [0.5, 0.5]), the label column is generated by applying the qcut() function of the pandas library to the ratio of closing prices to opening prices for each day.

To split the data into training and testing sets for that year, the function extracts the year from the date column of st_data. The training and testing data are then returned as numpy arrays.
"""
def create_stock_data(df_close,df_open,st):
    st_data = pd.DataFrame([])
    st_data['Date'] = list(df_close['Date'])
    st_data['Name'] = [st]*len(st_data)
    
    daily_change = df_close[st]/df_open[st]-1
    m = list(range(1,20))+list(range(20,241,20))
    for k in m:
        st_data['IntraR'+str(k)] = daily_change.shift(k)
    for k in m:
        st_data['CloseR'+str(k)] = df_close[st].pct_change(k).shift(1)
    for k in m:
        st_data['OverNR'+str(k)] = df_open[st]/df_close[st].shift(k)-1
        
    st_data['R-future'] = daily_change 
    st_data['label'] = list(label[st]) 
    st_data['Month'] = list(df_close['Date'].str[:-3])
    st_data = st_data.dropna()
    
    trade_year = st_data['Month'].str[:4]
    st_data = st_data.drop(columns=['Month'])
    st_train_data = st_data[trade_year<str(test_year)]
    st_test_data = st_data[trade_year==str(test_year)]
    return np.array(st_train_data),np.array(st_test_data) 

"""
In this code, a loop is performed over a range of test years from 1993 to 2019. Each time the loop repeats, it reads in the daily stock prices for a given year and creates a label that indicates whether the daily price change was in the top or bottom 50% of all price changes. To create training and testing data, it creates a list of stock names for that year. A Pandas DataFrame of features is generated for each stock using the create_stock_data() function, including intra-day returns, close-to-close returns, and overnight returns, in addition to the label. As a result, it concatenates these features across all stocks, both for training and testing.

Using the training and testing sets, trainer() fits a random forest classifier model to the training data and generates predictions for the testing data. Using the model predictions, the simulate() function simulates a trading strategy and calculates the average daily returns. Lastly, a file containing the average daily returns and corresponding statistics is created. A pickle file is also created for each year's predictions. The purpose of this code is to train and test a random forest classifier model for predicting stock price movements and to simulate a trading strategy based on those predictions.

"""
result_folder = 'results-Intraday-240-3-RF'
for directory in [result_folder]:
    if not os.path.exists(directory):
        os.makedirs(directory)

for test_year in range(1993,2020):
    
    print('-'*40)
    print(test_year)
    print('-'*40)
    
    filename = 'data/Open-'+str(test_year-3)+'.csv'
    df_open = pd.read_csv(filename)
    filename = 'data/Close-'+str(test_year-3)+'.csv'
    df_close = pd.read_csv(filename)
    
    label = create_label(df_open,df_close)
    stock_names = sorted(list(constituents[str(test_year-1)+'-12']))
    train_data,test_data = [],[]
    
    start = time.time()
    for st in stock_names:
        st_train_data,st_test_data = create_stock_data(df_close,df_open,st)
        train_data.append(st_train_data)
        test_data.append(st_test_data)

    train_data = np.concatenate([x for x in train_data])
    test_data = np.concatenate([x for x in test_data])
    
    print('Created :',train_data.shape,test_data.shape,time.time()-start)
    
    predictions = trainer(train_data,test_data)
    returns = simulate(test_data,predictions)
    result = Statistics(returns.sum(axis=1))
    print('\nAverage returns prior to transaction charges')
    result.shortreport() 
    
    with open(result_folder+'/predictions-'+str(test_year)+'.pickle', 'wb') as handle:
        pickle.dump(predictions, handle, protocol=pickle.HIGHEST_PROTOCOL)
    
    returns.to_csv(result_folder+'/avg_daily_rets-'+str(test_year)+'.csv')
    with open(result_folder+"/avg_returns.txt", "a") as myfile:
        res = '-'*30 + '\n' 
        res += str(test_year) + '\n'
        res += 'Mean = ' + str(result.mean()) + '\n'
        res += 'Sharpe = '+str(result.sharpe()) + '\n'
        res += '-'*30 + '\n'
        myfile.write(res)
        
