"""
Pandas, NumPy, Random, Time, Pickle, Sklearn's OneHotEncoder and RobustScaler, Keras' CuDNNLSTM, Dropout, Dense, Input, EarlyStopping, ModelCheckpoint, CSVLogger, Model, Sequential, load_model, optimizers, and Statistics are imported into the code, along with TensorFlow. In addition, the warnings module is imported and used to suppress any warning messages.
"""
import pandas as pd
import numpy as np
import random
import time
import pickle
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import RobustScaler
from Statistics import Statistics

import tensorflow as tf
from tensorflow.keras.layers import CuDNNLSTM, Dropout,Dense,Input 
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, CSVLogger
from tensorflow.keras.models import Model, Sequential, load_model
from tensorflow.keras import optimizers
import warnings
warnings.filterwarnings("ignore")

"""
It ensures that the generated random numbers are reproducible across multiple runs by setting the seed value for the random number generators used in the script. To ensure that hash-based operations are also deterministic, the random.seed() and np.random.seed() functions are set to the same value, as well as os.environ['PYTHONHASHSEED'].
"""
import os
SEED = 9
os.environ['PYTHONHASHSEED']=str(SEED)
random.seed(SEED)
np.random.seed(SEED)

"""
This code loads the S&P 500 index constituents data from a CSV file named "SPXconst.csv" and creates a dictionary named "constituents" with dates as keys and sets of company names as values.

The S&P 500 index constituents are then stored in a dictionary called "constituents_train". For-loops iterate through test years 1993-2015. A list of month strings is created for each test year, where each string represents a month in that year's training data. Using the "constituents" dictionary, each month's company names are obtained and stored in a single list using list comprehension. With the test year as the key, the "constituents_train" dictionary stores the list as a set.
"""
SP500_df = pd.read_csv('data/SPXconst.csv')
all_companies = list(set(SP500_df.values.flatten()))
all_companies.remove(np.nan)

constituents = {'-'.join(col.split('/')[::-1]):set(SP500_df[col].dropna()) 
                for col in SP500_df.columns}

constituents_train = {} 
for test_year in range(1993,2016):
    months = [str(t)+'-0'+str(m) if m<10 else str(t)+'-'+str(m) 
              for t in range(test_year-3,test_year) for m in range(1,13)]
    constituents_train[test_year] = [list(constituents[m]) for m in months]
    constituents_train[test_year] = set([i for sublist in constituents_train[test_year] 
                                         for i in sublist])

"""
An LSTM model can be defined and compiled by the function makeLSTM with one CuDNNLSTM layer, a dropout layer, and then a dense layer with softmax activation. Model input shape is (240,3), which means it expects 240 timesteps with 3 features at each timestep. For each input sequence, the CuDNNLSTM layer returns a hidden state output. Overfitting can be prevented during training by the Dropout layer, which has a rate of 0.1. A softmax activation function is used to generate probabilities for each class (long and short). Categorical cross-entropy is used as the loss function, and RMSprop is used as the optimizer. In the end, the model is compiled and a summary is printed.
"""
def makeLSTM():
    inputs = Input(shape=(240,3))
    x = CuDNNLSTM(25,return_sequences=False)(inputs)
    x = Dropout(0.1)(x)
    outputs = Dense(2,activation='softmax')(x)
    model = Model(inputs=inputs, outputs=outputs)
    model.compile(loss='categorical_crossentropy',optimizer=optimizers.RMSprop(),
                          metrics=['accuracy'])
    model.summary()
    return model
    

"""
Keras callbacks are returned by the callbacks_req() function. By default, the function takes one optional parameter model_type.

Callbacks are returned by the function as a list:

The CSVLogger callback logs training metrics to a CSV file.

EarlyStopping: This callback stops the training process when a monitored metric stops improving. Validation loss is the metric being monitored, and it should be minimized. If the validation loss does not improve after 10 epochs, the patience parameter is set to 10.

The ModelCheckpoint callback saves the model after every epoch. Inference and further training can be performed using the saved models. An epoch number and the model type are included in the file name when saving the model.
"""
def callbacks_req(model_type='LSTM'):
    csv_logger = CSVLogger(model_folder+'/training-log-'+model_type+'-'+str(test_year)+'.csv')
    filepath = model_folder+"/model-" + model_type + '-' + str(test_year) + "-E{epoch:02d}.h5"
    model_checkpoint = ModelCheckpoint(filepath, monitor='val_loss',save_best_only=False, period=1)
    earlyStopping = EarlyStopping(monitor='val_loss',mode='min',patience=10,restore_best_weights=True)
    return [csv_logger,earlyStopping,model_checkpoint]

"""
A 2D numpy array with 3 columns is reshaped into a 3D numpy array with shape (n_samples, 240, 3), where n_samples is the number of samples in the original 2D array.

Input array has shape (n_samples, 3), with the first column containing date values, the second column containing intra-day returns, and the third column containing future returns.

Using np.split, the function first splits the original 2D array into three arrays, one for each column. It then swaps the axes of the three arrays so that intra-day returns, future returns, and date values are on separate axes. The function then combines these three arrays into a single 3D array.
"""
def reshaper(arr):
    arr = np.array(np.split(arr,3,axis=1))
    arr = np.swapaxes(arr,0,1)
    arr = np.swapaxes(arr,1,2)
    return arr

"""
By using training data, the function trainer trains an LSTM model and makes predictions based on test data. Input arguments train_data and test_data are NumPy arrays containing training and testing data. Initially, the training data is shuffled, and then the features, target labels, and returns are separated. Using the OneHotEncoder function from sklearn.preprocessing, target labels are one-hot encoded. To reshape the input feature data for the LSTM model, the function reshaper is called.

By calling the makeLSTM function, the function creates the LSTM model. RMSprop optimizer and categorical_crossentropy loss function are used to compile the model. It is then trained using 1000 epochs of training data and 512 batches. Callbacks_req sets model checkpoints, logs, and early stopping.

When the model has been trained, the function creates a dictionary prediction, in which the keys are dates in the test data, and the values are predicted probabilities. In the LSTM model, test data is reshaped using the reshaper function, and predictions are made using the predict method. The trained LSTM model and the dictionary of predictions are then returned.
"""
def trainer(train_data,test_data):
    np.random.shuffle(train_data)
    train_x,train_y,train_ret = train_data[:,2:-2],train_data[:,-1],train_data[:,-2]
    train_x = reshaper(train_x)
    train_y = np.reshape(train_y,(-1, 1))
    train_ret = np.reshape(train_ret,(-1, 1))
    enc = OneHotEncoder(handle_unknown='ignore')
    enc.fit(train_y)
    enc_y = enc.transform(train_y).toarray()
    train_ret = np.hstack((np.zeros((len(train_data),1)),train_ret)) 

    model = makeLSTM()
    callbacks = callbacks_req()
    
    model.fit(train_x,
              enc_y,
              epochs=1000,
              validation_split=0.2,
              callbacks=callbacks,
              batch_size=512
              )

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = reshaper(test_d[:,2:-2])
        predictions[day] = model.predict(test_d)[:,1]
    return model,predictions
#-------------------------------------

"""
There are three arguments to the function trained: filename, train_data, and test_data. The filename argument specifies the path and name of the file containing the trained model. A numpy array containing the training and testing data is passed in as train_data and test_data arguments.

Using the load_model function from the Keras API, the function loads the trained model from the specified file. It then loops through each unique date in the testing data and selects the corresponding subset. It uses the np.reshape function to reshape the test data into the shape expected by the model (i.e., a three-dimensional array of shape (num_samples, 240, 1)). On the reshaped testing data, it uses the predict method of the model to make predictions. Using the date as the key, the predicted probabilities of the positive class (i.e., class 1) are stored in a dictionary prediction. Lastly, the function returns the trained model and the predictions.
"""
def trained(filename,train_data,test_data):
    model = load_model(filename)

    dates = list(set(test_data[:,0]))
    predictions = {}
    for day in dates:
        test_d = test_data[test_data[:,0]==day]
        test_d = np.reshape(test_d[:,2:-2],(len(test_d),240,1))
        predictions[day] = model.predict(test_d)[:,1]
    return model,predictions     

"""
Two arguments are passed to the simulate function: test_data and predictions.

NumPy array test_data has shape (n, 243), where n represents the number of rows (instances) and 243 represents the features and labels. The first column of test_data represents the date, the second column represents the stock name, the third to the 242nd columns represent the 240 intraday returns of the stock (i.e., the difference between the stock's closing price and its opening price at 10-minute intervals for a trading day), and the last column represents the true return on the day.

The LSTM model predicts the probabilities that the stocks will go up on each day in a Python dictionary, where the keys are the unique dates in test_data and values are the values.

The function then simulates trading based on the predicted probabilities. The top k stocks with the highest predicted probabilities are bought each day, and the bottom k stocks with the lowest predicted probabilities are shorted. Here k=10. In a Pandas DataFrame named rets, it calculates the average returns of the top k long positions and the bottom k short positions for each day.

Lastly, the function prints the mean of the rets DataFrame as the result of the simulation.
"""
def simulate(test_data,predictions):
    rets = pd.DataFrame([],columns=['Long','Short'])
    k = 10
    for day in sorted(predictions.keys()):
        preds = predictions[day]
        test_returns = test_data[test_data[:,0]==day][:,-2]
        top_preds = predictions[day].argsort()[-k:][::-1] 
        trans_long = test_returns[top_preds]
        worst_preds = predictions[day].argsort()[:k][::-1] 
        trans_short = -test_returns[worst_preds]
        rets.loc[day] = [np.mean(trans_long),np.mean(trans_short)] 
    print('Result : ',rets.mean())  
    return rets       

    
"""
A list of percentiles perc and two data frames df_open and df_close are input into the create_label function. Based on the price change of each stock, it returns a new dataframe label for each trading day.

First, the function checks if the date indices of the two dataframes are the same. It then subtracts one from the closing price to the opening price to calculate the daily percentage change for each stock.

The function then calculates quantiles of the daily percentage change distribution for each stock using the qcut method from pandas. Based on the percentiles given in perc, the qcut method segments the distribution into intervals and labels each observation accordingly. Percentile labels range from 0 to the number of percentiles given in perc minus 1.

Since the first row does not have any percentage change values to calculate labels for, the function returns the label dataframe without the first row.
"""
def create_label(df_open,df_close,perc=[0.5,0.5]):
    if not np.all(df_close.iloc[:,0]==df_open.iloc[:,0]):
        print('Date Index issue')
        return
    perc = [0.]+list(np.cumsum(perc))
    label = (df_close.iloc[:,1:]/df_open.iloc[:,1:]-1).apply(
            lambda x: pd.qcut(x.rank(method='first'),perc,labels=False), axis=1)
    return label[1:]

"""
df_open, df_close, st, and m are the arguments to the function create_stock_data().

Input data df_open and df_close represent the open and close prices of a specific stock. st is the name of the stock and m is the number of previous days we should consider intra-day returns for.

This function creates a pandas DataFrame st_data that contains the columns 'Date', 'Name', 'IntraR', 'NextR', 'CloseR', 'IntraR-future', 'label', and 'Month'.

The intra-day returns for each stock are calculated and stored in the columns 'IntraR[k]' for each of the previous m days. Similarly, it calculates the next-day return for each of the m days, stores it in the columns 'NextR[k]', and shifts it by k days.

For each of the previous m days, it calculates the percentage change in the closing price of the stock and stores it in the column 'CloseR{k}'. In addition, it calculates the intra-day return for the next day and stores it in the column 'IntraR-future'.

Then, a new column called 'label' is added and filled with values generated by the create_label() function, which creates a label for every row based on its percentile ranking in the distribution of all stocks' intra-day returns for the same day.

Finally, the function creates a column called 'Month' from the 'Date' column and removes it from the DataFrame.

Based on the trade year, the function then splits the DataFrame into training and testing data and returns them as numpy arrays.
"""
def create_stock_data(df_open,df_close,st,m=240):
    st_data = pd.DataFrame([])
    st_data['Date'] = list(df_close['Date'])
    st_data['Name'] = [st]*len(st_data)
    daily_change = df_close[st]/df_open[st]-1
    for k in range(m)[::-1]:
        st_data['IntraR'+str(k)] = daily_change.shift(k)

    nextday_ret = (np.array(df_open[st][1:])/np.array(df_close[st][:-1])-1)
    nextday_ret = pd.Series(list(nextday_ret)+[np.nan])     
    for k in range(m)[::-1]:
        st_data['NextR'+str(k)] = nextday_ret.shift(k)

    close_change = df_close[st].pct_change()
    for k in range(m)[::-1]:
        st_data['CloseR'+str(k)] = close_change.shift(k)

    st_data['IntraR-future'] = daily_change.shift(-1)    
    st_data['label'] = list(label[st])+[np.nan] 
    st_data['Month'] = list(df_close['Date'].str[:-3])
    st_data = st_data.dropna()
    
    trade_year = st_data['Month'].str[:4]
    st_data = st_data.drop(columns=['Month'])
    st_train_data = st_data[trade_year<str(test_year)]
    st_test_data = st_data[trade_year==str(test_year)]
    return np.array(st_train_data),np.array(st_test_data) 

"""
It takes in train_data and test_data, which are numpy arrays containing data for a single stock. After fitting a RobustScaler to train_data, both train_data and test_data are transformed using this scaler. The function applies a robust scaling to the OpenR0 to OpenR239 and CloseR0 to CloseR239 columns of train_data and test_data. After subtracting the median value, the data is scaled to the IQR (interquartile range). By normalizing the features, a neural network can use them as inputs since they are scaled to a common range. In the code, the scaler object is returned from the function, but it is not used further.
"""
def scalar_normalize(train_data,test_data):
    scaler = RobustScaler()
    scaler.fit(train_data[:,2:-2])
    train_data[:,2:-2] = scaler.transform(train_data[:,2:-2])
    test_data[:,2:-2] = scaler.transform(test_data[:,2:-2])    
    
"""
Using 240-minute data for the period 1993 to 2019, the code trains and tests a model for making intraday trading predictions. To predict whether a stock's return will be positive or negative, we used a 3-layer LSTM network with 25 neurons in the first layer, and a softmax output layer with two neurons.

The code creates training and testing data for each stock in the S&P 500 index every year. The training data is then used to fit the LSTM model, and the testing data is used to make predictions. In order to calculate the average daily returns for that year, these predictions are used to simulate long and short positions in the stocks.

Each year's results are saved in a folder called "results-Intraday-240-3-LSTM", which contains the mean and Sharpe ratio for each year as well as the average daily returns. In addition, the code saves the trained model for each year in a folder called "models-Intraday-240-3-LSTM".
"""
model_folder = 'models-Intraday-240-3-LSTM'
result_folder = 'results-Intraday-240-3-LSTM'
for directory in [model_folder,result_folder]:
    if not os.path.exists(directory):
        os.makedirs(directory)

for test_year in range(1993,2020):
    
    print('-'*40)
    print(test_year)
    print('-'*40)
    
    filename = 'data/Open-'+str(test_year-3)+'.csv'
    df_open = pd.read_csv(filename)
    filename = 'data/Close-'+str(test_year-3)+'.csv'
    df_close = pd.read_csv(filename)
    
    label = create_label(df_open,df_close)
    stock_names = sorted(list(constituents[str(test_year-1)+'-12']))
    train_data,test_data = [],[]

    start = time.time()
    for st in stock_names:
        st_train_data,st_test_data = create_stock_data(df_open,df_close,st)
        train_data.append(st_train_data)
        test_data.append(st_test_data)
      
    train_data = np.concatenate([x for x in train_data])
    test_data = np.concatenate([x for x in test_data])
    
    scalar_normalize(train_data,test_data)
    print(train_data.shape,test_data.shape,time.time()-start)
    
    model,predictions = trainer(train_data,test_data)
    returns = simulate(test_data,predictions)
    returns.to_csv(result_folder+'/avg_daily_rets-'+str(test_year)+'.csv')
    
    result = Statistics(returns.sum(axis=1))
    print('\nAverage returns prior to transaction charges')
    result.shortreport() 
    
    with open(result_folder+"/avg_returns.txt", "a") as myfile:
        res = '-'*30 + '\n'
        res += str(test_year) + '\n'
        res += 'Mean = ' + str(result.mean()) + '\n'
        res += 'Sharpe = '+str(result.sharpe()) + '\n'
        res += '-'*30 + '\n'
        myfile.write(res)
            
